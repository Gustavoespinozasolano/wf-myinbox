sap.ui.define(["sap/ui/core/mvc/Controller",
		"sap/m/MessageBox",
		"./utilities",
		"sap/ui/core/routing/History",
		"sap/m/MessageToast",
		"sap/ui/model/Filter"
	],
	function (e, t, o, n, r, Filter) {
		"use strict";
		var i;
		return e.extend("com.everis.suppliers.invoiceregister.controller.PoLine", {
			handleRouteMatched: function (e) {
				this.getView().setModel(sap.ui.getCore().getModel("TipDoc"), "TipDoc");
				var oItemRoute = sap.ui.getCore().getModel("TipDoc").getData();
				var t = e.getParameter("data");
				var o = new sap.ui.model.Filter({
					path: "ClasePedido",
					operator: "EQ",
					value1: "1"
				});
				var aFilters = [];
				aFilters.push(new Filter({
					path: "ClasePedido",
					operator: "EQ",
					value1: "1"
				}));
				aFilters.push(new Filter({
					path: "DocTypeSunat",
					operator: "EQ",
					value1: oItemRoute.DocTypeSunat
				}));
				if (t.context) {
					this.fecha = t.date;
					this.reference = t.reference;
					this.sContext = t.context;
					if (this.sContext) {
						var n = {
							path: "/" + this.sContext,
							filters: aFilters
						};
						this.getView().bindObject(n);
					}
				}
				var r = this.getView().byId("Detalle");
				var i = this.getView().getModel("TipDoc");
				if (i.getData().TipDoc === "02") {
					r.getColumns()[6].setVisible(false);
					r.getColumns()[7].setVisible(true);
				} else {
					r.getColumns()[6].setVisible(true);
					r.getColumns()[7].setVisible(false);
				}
				var s = r.getBinding("items");
				s.filter(aFilters);
				this.addMsg()
			},
			addMsg: function () {
				if (this.getOwnerComponent().getModel("oMsg")) {
					var e = this.getOwnerComponent().getModel("oMsg").arreglo;
					for (var t = 0; t < e.length; t++) {
						this._addPopoverMessage(e[t].type, e[t].title, e[t].msg)
					}
				}
			},
			_updatePopoverCounter: function () {
				$._popoverCount = $._popoverCount + 1;
				if (this.getView()) {
					this.getView().byId("popoverButton").setText("Mensajes (" + $._popoverCount + ")")
				}
			},
			_addPopoverMessage: function (e, t, o) {
				$._popoverData.push({
					type: e,
					title: t,
					description: o
				});
				$._popoverModel.setData($._popoverData);
				this._updatePopoverCounter()
			},
			onRegistrar: function () {
				i = this.getView().getModel("i18n").getResourceBundle();
				var e = this.getView().getModel();
				var t = this.sContext;
				var o = e.oData[t];
				var n = {};
				var s = this.byId("Detalle").getSelectedItems();
				if (!s.length) {
					sap.m.MessageToast.show("Debe seleccionar al menos una posición");
					return false
				}
				n.ConexionPIPO = "";
				var a = this.byId("chkPIPO");
				if (a.getSelected()) {
					n.ConexionPIPO = "X"
				}
				n.DOCUMENTTYPE = "01";
				n.ClasePedido = o.ClasePedido;
				n.SUPPLIERID = sap.ushell.Container.getService("UserInfo").getUser().getId();
				n.PAYMENT_TERMS = "";
				n.PO_NUMBER = o.PO_NUMBER;
				n.REFERENCE = this.reference;
				n.TOTAL_VALUE = o.TOTAL_VALUE;
				n.CURRENCY = o.CURRENCY;
				n.COMPANY_CODE = o.ItCompanyId;
				n.ORDER_DATE = "";
				n.TYPE = "";
				n.MESSAGE = "";
				n.COMPANY = o.COMPANY;
				n.DN_NUMBER = o.DN_NUMBER;
				n.DOC_DATE = this.fecha;
				n.PoLineSet = [];
				n.RegHeaderToPos = [];
				for (var g = 0; g < s.length; g++) {
					var l = s[g].getBindingContext().getObject();
					if (l.PO_NUMBER === n.PO_NUMBER) {
						var u = {};
						u.PO_NUMBER = l.PO_NUMBER;
						u.PO_UNIT = l.PO_UNIT;
						u.ItCompanyId = l.ItCompanyId;
						u.ITEMNUMBER = l.ITEMNUMBER;
						u.MATERIALNUMBER = l.MATERIALNUMBER;
						u.ITEMDESCRIPTION = l.ITEMDESCRIPTION;
						u.QUANTITY = l.QUANTITY.replace(/,/g, "");
						u.UNITPRICE = l.UNITPRICE.replace(/,/g, "");
						u.CURRENCY = l.CURRENCY;
						u.SUBTOTAL = l.SUBTOTAL.replace(/,/g, "");
						n.PoLineSet.push(u)
					}
				}
				var d = this;
				e.create("/InvoiceRegSet", n, {
					success: function (e, t) {
						r.show(t.data.MESSAGE);
						var o = t.data;
						if (o.TYPE === "E") {
							d._addPopoverMessage("Error", i.getText("PopTitle") + o.PO_NUMBER, o.MESSAGE)
						} else {
							d._addPopoverMessage("Success", i.getText("PopTitle") + o.PO_NUMBER, o.MESSAGE)
						}
					},
					error: function (e) {
						r.show(i.getText("Error"));
						d._addPopoverMessage("Error", i.getText("PopTitle") + n.PO_NUMBER, i.getText("ErrorMsg"))
					}
				})
			},
			onListUpdateFinishedPosition: function () {
				var e = this.getView().byId("Detalle");
				var t = [];
				var o = e.getItems();
				var n = true;
				var r = [];
				var i = {};
				var s = this.getOwnerComponent().getModel("oDetalleArr");
				var a = this;
				if (s) {
					var g = a.getOwnerComponent().getModel("oDetalleArr");
					r = g.arreglo;
					for (var l = 0; l < r.length; l++) {
						if (o[0].getBindingContext().getObject().PO_NUMBER) {
							if (o[0].getBindingContext().getObject().PO_NUMBER === r[l]) {
								n = false;
								if (n) {
									r.push(o[0].getBindingContext().getObject().PO_NUMBER);
									i.arreglo = r;
									a.getOwnerComponent().setModel(i, "oDetalleArr")
								}
							}
						}
					}
				}
				for (var l = 0; l < o.length; l++) {
					t.push(o[l].getBindingContext().getObject())
				}
				if (this.getOwnerComponent().getModel("oDetallePO")) {
					var u = this.getOwnerComponent().getModel("oDetallePO");
					var d = JSON.parse(u.getJSON());
					var h = d.arreglo;
					for (l = 0; l < h.length; l++) {
						t.push(h[l])
					}
				}
				var f = {};
				f.arreglo = t;
				var c = new sap.ui.model.json.JSONModel(f);
				this.getOwnerComponent().setModel(c, "oDetallePO");
				if (this.getOwnerComponent().getModel("oDetallePO")) {
					u = this.getOwnerComponent().getModel("oDetallePO");
					d = JSON.parse(u.getJSON());
					this.oInfoPO_ = d
				}
			},
			onSelectionChange: function () {
				i = this.getView().getModel("i18n").getResourceBundle();
				var e = this.getView().byId("Detalle");
				var t = [];
				var o = e.getSelectedItems();
				var n = e.getItems();
				var s = n[0].getBindingContext().getObject().PO_NUMBER;
				if (o.length < 1) {
					r.show(i.getText("Empty1") + s);
					e.selectAll()
				}
				if (o.length === n.length) {
					o = []
				}
				for (var a = 0; a < o.length; a++) {
					t.push(o[a].getBindingContext().getObject())
				}
				if (this.getOwnerComponent().getModel("oDetallePO")) {
					var g = this.getOwnerComponent().getModel("oDetallePO");
					var l = JSON.parse(g.getJSON());
					var u = l.arreglo;
					for (a = 0; a < u.length; a++) {
						if (u[a].PO_NUMBER !== s) {
							t.push(u[a])
						}
					}
				}
				var d = {};
				d.arreglo = t;
				var h = new sap.ui.model.json.JSONModel(d);
				this.getOwnerComponent().setModel(h, "oDetallePO");
				if (this.getOwnerComponent().getModel("oDetallePO")) {
					g = this.getOwnerComponent().getModel("oDetallePO");
					l = JSON.parse(g.getJSON())
				}
			},
			_onPageNavButtonPress: function () {
				var e = n.getInstance();
				var t = e.getPreviousHash();
				var o = this.getQueryParameters(window.location);
				if (t !== undefined || o.navBackToLaunchpad) {
					window.history.go(-1)
				} else {
					var r = sap.ui.core.UIComponent.getRouterFor(this);
					r.navTo("default", true)
				}
			},
			getQueryParameters: function (e) {
				var t = {};
				var o = e.search.substring(1).split("&");
				for (var n = 0; n < o.length; n++) {
					var r = o[n].split("=");
					t[r[0]] = decodeURIComponent(r[1])
				}
				return t
			},
			_onButtonPress: function (e) {
				e = jQuery.extend(true, {}, e);
				return new Promise(function (e) {
					e(true)
				}).then(function (t) {
					var o = e.getSource().getBindingContext();
					return new Promise(function (e) {
						this.doNavigate("CabeceraOc", o, e, "")
					}.bind(this))
				}.bind(this)).then(function (e) {
					if (e === false) {
						return false
					} else {
						var t = this.getView();
						var o = this;
						return new Promise(function (e, n) {
							var r = o.oModel;
							var i = function (e) {
								r.resetChanges();
								n(new Error(e))
							};
							if (r && r.hasPendingChanges()) {
								r.submitChanges({
									success: function (n) {
										var s = n.__batchResponses[0];
										var a = s.__changeResponses && s.__changeResponses[0];
										if (a && a.data) {
											var g = r.getKey(a.data);
											t.unbindObject();
											t.bindObject({
												path: "/" + g
											});
											if (window.history && window.history.replaceState) {
												window.history.replaceState(undefined, undefined, window.location.hash.replace(encodeURIComponent(o.sContext),
													encodeURIComponent(g)))
											}
											r.refresh();
											e()
										} else if (a && a.response) {
											i(a.message)
										} else if (!a && s.response) {
											i(s.message)
										} else {
											r.refresh();
											e()
										}
									},
									error: function (e) {
										n(new Error(e.message))
									}
								})
							} else {
								e()
							}
						})
					}
				}.bind(this)).then(function (e) {
					if (e === false) {
						return false
					} else {
						return new Promise(function (e) {
							var t = "";
							t = t === "default" ? undefined : t;
							sap.m.MessageToast.show("Pre-Registro Exitoso", {
								onClose: e,
								duration: 0 || 3e3,
								at: t,
								my: t
							})
						})
					}
				}.bind(this)).catch(function (e) {
					if (e !== undefined) {
						t.error(e.message)
					}
				})
			},
			doNavigate: function (e, t, o, n) {
				var r = t ? t.getPath() : null;
				var i = t ? t.getModel() : null;
				var s;
				if (r !== null && r !== "") {
					if (r.substring(0, 1) === "/") {
						r = r.substring(1)
					}
					s = r.split("(")[0]
				}
				var a;
				var g = this.sMasterContext ? this.sMasterContext : r;
				if (s !== null) {
					a = n || this.getOwnerComponent().getNavigationPropertyForNavigationWithContext(s, e)
				}
				if (a !== null && a !== undefined) {
					if (a === "") {
						this.oRouter.navTo(e, {
							context: r,
							masterContext: g
						}, false)
					} else {
						i.createBindingContext(a, t, null, function (t) {
							if (t) {
								r = t.getPath();
								if (r.substring(0, 1) === "/") {
									r = r.substring(1)
								}
							} else {
								r = "undefined"
							}
							if (r === "undefined") {
								this.oRouter.navTo(e)
							} else {
								this.oRouter.navTo(e, {
									context: r,
									masterContext: g
								}, false)
							}
						}.bind(this))
					}
				} else {
					this.oRouter.navTo(e)
				}
				if (typeof o === "function") {
					o()
				}
			},
			_onButtonPress1: function (e) {
				e = jQuery.extend(true, {}, e);
				return new Promise(function (e) {
					e(true)
				}).then(function (t) {
					var o = e.getSource().getBindingContext();
					return new Promise(function (e) {
						this.doNavigate("CabeceraOc", o, e, "")
					}.bind(this))
				}.bind(this)).then(function (e) {
					if (e === false) {
						return false
					} else {
						return new Promise(function (e) {
							var t, o;
							var n = this.oModel;
							if (n && n.hasPendingChanges()) {
								t = Object.keys(n["mChangedEntities"]);
								for (var r = 0; r < t.length; r++) {
									o = n.getContext("/" + t[r]);
									if (o && o.bCreated) {
										n.deleteCreatedEntry(o)
									}
								}
								n.resetChanges()
							}
							e()
						}.bind(this))
					}
				}.bind(this)).then(function (e) {
					if (e === false) {
						return false
					} else {
						return new Promise(function (e) {
							var t = "";
							t = t === "default" ? undefined : t;
							sap.m.MessageToast.show("No Guardado", {
								onClose: e,
								duration: 0 || 3e3,
								at: t,
								my: t
							})
						})
					}
				}.bind(this)).catch(function (e) {
					if (e !== undefined) {
						t.error(e.message)
					}
				})
			},
			onInit: function () {
				this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				this.oRouter.getTarget("PoLine").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));
				this.oModel = this.getOwnerComponent().getModel()
			},
			formatNumber: function (e) {
				jQuery.sap.require("sap.ui.core.format.NumberFormat");
				var t = new sap.ui.core.Locale("en-US");
				var o = {
					minIntegerDigits: 3,
					minFractionDigits: 2,
					maxFractionDigits: 2
				};
				var n = sap.ui.core.format.NumberFormat.getFloatInstance(o, t);
				return n.format(e).replace(/^\b0+\B/, "")
			},
			_handleMessagePopoverPress: function (e) {
				if (!$._oMessagePopover.isOpen()) {
					$._oMessagePopover.openBy(e.getSource())
				} else {
					$._oMessagePopover.close()
				}
			}
		})
	}, true);