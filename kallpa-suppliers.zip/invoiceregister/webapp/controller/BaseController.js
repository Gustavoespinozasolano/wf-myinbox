sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/Device",
	"sap/m/MessageBox",
	'sap/ui/core/Fragment',
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/BusyIndicator",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"../model/formatter",
	"../service/oData",
	"../service/SharePoint",
	"../service/DocumentService"
], function (Controller, Device, MessageBox, Fragment, JSONModel, BusyIndicator, MessageToast, Filter, Formatter, oDataService,
	SharePoint, DocumentService) {
	"use strict";
	return Controller.extend("com.everis.suppliers.invoiceregister.controller.BaseController", {
		getI18nText: function (sText) {
			return this.oView.getModel("i18n") === undefined ? this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(sText) :
				this.oView.getModel("i18n").getResourceBundle().getText(sText);
		},
		getResourceBundle: function () {
			return this.oView.getModel("i18n").getResourceBundle();
		},
		getModel: function (sModel) {
			return this.oView.getModel(sModel);
		},
		_byId: function (sName) {
			var cmp = this.byId(sName);
			if (!cmp) {
				cmp = sap.ui.getCore().byId(sName);
			}
			return cmp;
		},
		getMessageBox: function (sType, sMessage) {
			return MessageBox[sType](sMessage);
		},
		setValidateStep: function (sIdStep, bValidate) {
			var oStep = this._byId(sIdStep);
			oStep.setValidated(bValidate);
		},
		removeZerosLeft: function (sValue) {
			var sReturn = "";
			if (sValue !== undefined) {
				sReturn = sValue.replace(/^0+/, '');
			}
			return sReturn;
		},
		alrh450: function (sModel) {
			var _this = this;
			_this.oInterval = setInterval(this.myScanner, 1500, sModel, _this);
		},
		getDaysBefore: function (date, days) {
			var _24HoursInMilliseconds = 86400000;
			var daysAgo = new Date(date.getTime() + days * _24HoursInMilliseconds);
			daysAgo.setHours(0);
			daysAgo.setMinutes(0);
			daysAgo.setSeconds(0);
			return daysAgo;
		},
		clearInterval: function () {
			clearInterval(this.oInterval);
		},
		setFragment: function (that, sDialogName, sFragmentId, sNameFragment, sRoute) {
			try {
				if (!that[sDialogName]) {
					that[sDialogName] = sap.ui.xmlfragment(sFragmentId, sRoute + "." + sNameFragment,
						that);
					that.getView().addDependent(that[sDialogName]);
				}
				that[sDialogName].addStyleClass(
					"sapUiResponsivePadding--content sapUiResponsivePadding--header sapUiResponsivePadding--footer sapUiResponsivePadding--subHeader"
				)

			} catch (err) {
				//	that.showErrorMessage(that.getI18nText("error"), error);
				console.log(err);
			}
		},
		onFileSizeExceed: function () {
			MessageBox.error(this.getI18nText("msgFileSizeExceed"));
		},
		onFilenameLengthExceed: function () {
			MessageBox.error(this.getI18nText("msgFilenameLengthExceed"));
		},
		showErrorMessage: function (sError, sDetail) {
			var sDetail2 = String(sDetail);
			return MessageBox.error(sError, {
				title: "Error",
				details: sDetail2,
				styleClass: "sapUiSizeCompact",
				contentWidth: "100px"
			});
		},
		goNavConTo: function (sFragmentId, sNavId, sPageId) {
			Fragment.byId(sFragmentId, "btnIdNavDialog").setVisible(true);
			var oNavCon = Fragment.byId(sFragmentId, sNavId);
			var oDetailPage = Fragment.byId(sFragmentId, sPageId);
			oNavCon.to(oDetailPage);
		},
		getMessageBoxFlex: function (that, sType, sMessage, _this, aMessage, sAction, sRoute, sAction2) {
			return MessageBox[sType](sMessage, {
				actions: [sAction, sAction2],
				onClose: function (oAction) {
					if (oAction === sAction && sRoute === "ErrorNotificNumber") {
						that.createMessageLog(aMessage, that);
					}
					if (oAction === sAction && sRoute === "ErrorTakePhoto") {
						that._onTakePhoto();
					}
					if (oAction === sAction && sRoute === "SuccesRegister") {
						that.oRouter.navTo("RouteLaunchpadCreateNotific");
					}
					if (oAction === sAction2 && sRoute === "SuccessUpdateOffline") {
						that.oRouter.navTo("RouteNotificationOff");
					}
					if (oAction === sAction2 && sRoute === "SuccesRegister") {
						/*var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
						oCrossAppNavigator.toExternal({
							target: {
								semanticObject: "#"
							}
						});*/
						that.oRouter.navTo("RouteLaunchpad");
					}
					if (oAction === sAction && sRoute === "ErrorUpload") {
						BusyIndicator.show();
					}
				}
			});
		},
		createColumnConfig: function () {
			var e = [];
			e.push({
				label: "NUMERO DE ORDEN",
				type: "number",
				property: "PO_NUMBER",
				scale: 0
			});
			e.push({
				property: "COMPANY",
				type: "string"
			});
			e.push({
				label: "VALOR TOTAL",
				property: "TOTAL_VALUE",
				type: "string",
				scale: 2,
				delimiter: true
			});
			e.push({
				label: "MONEDA",
				property: "CURRENCY",
				type: "string"
			});
			e.push({
				label: "NUMERO DE FACTURA",
				property: "REFERENCE",
				type: "string"
			});
			e.push({
				label: "FECHA",
				property: "DOC_DATE",
				type: "string"
			});
			e.push({
				label: "TEXTO DE CABECERA",
				property: "HEADER_TXT",
				type: "string"
			});
			return e;
		},
		invoiceAlreadyRegistered: function (that, oResponse, oSource, l) {
			if (oResponse.Response === "1") {
				MessageBox.error(that.getI18nText("msginvoicealreadyregistered"));
				oSource.setValue("");
				if (l > -1) {
					that.getView().getModel("Masivo").getData()[0].numeroFactura = "";
					that.getView().getModel("Masivo").updateBindings(true);
				}
				return;
			}
		},
		validateInvoiceNumber: function () {
			/*var that = this;
			var t = this;
			var a = e.getDOMValue();
			var r = a.toUpperCase().replace(/\s/g, "");
			var o = r.split("-");
			var i = o.join("");
			var n = "";
			var l = e.getParent().getCells()[6];
			if (l === undefined) {
				n = e.getParent().getCells()[0].getSelectedKey()
			} else {
				n = e.getParent().getCells()[6].getSelectedKey()
			}
			var u = "";
			var d = this.getView().getModel("Usuario").getData().ruc;
			var g = this.getView().getModel("Contacto").getData().Legalenty === "EE" ? true : false;
			if (o.length === 2 && o[0].length == 4) {
				if (!/[^a-zA-Z0-9]/.test(i)) {
					if (g) {
						if (!this.onValidateFormatoNFactura(o[0])) {
							return MessageToast.show("Proveedor registrado como emisor electrónico, por favor ingrese una factura electrónica.")
						}
					}
					u = n + "-" + c.formatoReferencia(r);
					BusyIndicator.show(0);
					var sPath = that.oModel.createKey("/ReferenceSet", {
						Xblnr: u,
						Nif: d
					});
					oDataService.consult(that, "read", sPath, "", "").then(response => {
						BusyIndicator.hide();
						that.invoiceAlreadyRegistered(that, response, a, l);
					}).catch(err => {
						console.log(err);
					});
					e.setValue(c.formatoReferencia(r));
					return true;
				} else {
					MessageToast.show("No se permiten caracteres especiales");
					return false;
				}
			} else {
				MessageToast.show("N° Factura: Formato esperado XXXX-XXXXXXXX");
				return false;
			}
			return true;*/
		},
		saveFilesInRepository: function (that, sTypeRepository, aUploadColletionItems, aUploadAttachments, sFileName, sReference,
			aFilesSharePoint, p,
			oAnexoSet, oParentResponse, fI18n, sMessageAnexo, sFolderNameFile, oDataDS) {
			function convertFilesBlob(aUploadColletionItemsCopy) {
				if (aUploadColletionItemsCopy.length > 0) {
					var oUploadColletionItemsCopy = aUploadColletionItemsCopy.pop();
					var oFileReader = new FileReader();
					if (oUploadColletionItemsCopy.name === aUploadAttachments.xml.name) {
						sFileName = sReference + '.xml';
					} else if (oUploadColletionItemsCopy.name === aUploadAttachments.pdf.name) {
						sFileName = sReference + '.pdf';
					} else {
						sFileName = oUploadColletionItemsCopy.name;
					}
					oFileReader.onloadend = function (e) {
						var result = e.target.result;
						aFilesSharePoint.push({
							FileName: sFileName,
							ArrayBufferResult: result,
							FolderName: sFolderNameFile
						});
						convertFilesBlob(aUploadColletionItemsCopy);
					};
					oFileReader.readAsArrayBuffer(oUploadColletionItemsCopy);
				} else if (aFilesSharePoint.length > 0) {
					if (sTypeRepository === "SHAREPOINT") {
						//Sharepoint
						that.saveDocumentsInSharepoint(that, aFilesSharePoint, sFileName, p, aUploadColletionItems, oAnexoSet, oParentResponse,
							fI18n,
							sMessageAnexo, sFolderNameFile);
					} else if (sTypeRepository === "DOCUMENTSERVICE") {
						//DocumentService
						that.saveDocumentsInDocumentService(that, aFilesSharePoint, sFileName, p, aUploadColletionItems, oAnexoSet,
							oParentResponse,
							fI18n, oDataDS, null, sMessageAnexo);
					}
				}

			}
			var aUploadColletionItemsCopy = aUploadColletionItems.slice();

			convertFilesBlob(aUploadColletionItemsCopy);
		},
		saveDocumentsInSharepoint: function (that, aFilesSharePoint, sFileName, iCount, aUploadColletionItems, oAnexoSet, oParentResponse,
			fI18n,
			sMessageAnexo, sFolderNameFile) {
			SharePoint.createFolderDeep(that, that.sFullPath).then(response => {
				SharePoint.saveFiles(that, aFilesSharePoint).then(response => {
					//	if (iCount < aUploadColletionItems.length) {
					for (var i = 0; i < aFilesSharePoint.length; i++) {
						var t = {
							PO_NUMBER: oAnexoSet.PO_NUMBER,
							RUC: oAnexoSet.RUC,
							FOLIO: oAnexoSet.FOLIO,
							FILENAME: aFilesSharePoint[i].FileName
						};
						oAnexoSet.AnexoToFile.push(t);
					}

					//	}
					//if (iCount === aUploadColletionItems.length - 1) {
					oDataService.consult(that, "create", "/AnexoSet", oAnexoSet, "").then(data => {
						//Agrega un mensaje satisfactorio al log popover
						that._addPopoverMessage("Success", fI18n.getText("PopTitle") + sMessageAnexo, "Anexos Guardados");
						BusyIndicator.hide();
					}).catch(err => {
						//Agrega un mensaje error al log popover
						that._addPopoverMessage("Error", fI18n.getText("PopTitle") + sMessageAnexo, "Error al subir Anexos");
						BusyIndicator.hide();
						console.log(err);
					});
					//}
					iCount++;
				}).catch(err => {
					//Agrega un mensaje error al log popover
					that._addPopoverMessage("Error", fI18n.getText("PopTitle") + sMessageAnexo, err);
					console.log(err);
				});

			}).catch(err => {
				console.log(err)
			});
		},
		saveDocumentsInDocumentService: function (that, oBlob, sFileName, iCount, aUploadColletionItems, oAnexoSet, oParentResponse, fI18n,
			oDataDS, sReferencia, sMessageAnexo) {
			DocumentService.getQuery("SELECT cmis:objectId FROM cmis:document WHERE IN_FOLDER('" + oDataDS.FolderId + "') AND cmis:name = '" +
				sFileName +
				"'").then(
				function (o) {
					var s = o.results;
					if (s.length > 0) {
						var n = s[0].properties["cmis:objectId"].value;
						DocumentService.deleteObject(oDataDS.FolderId, n).then(function (o) {
							that.uploadFileInDocumentService(that, oBlob, oDataDS, sFileName, oAnexoSet, oParentResponse, aUploadColletionItems, fI18n,
								iCount, sMessageAnexo);
						});
					} else {
						that.uploadFileInDocumentService(that, oBlob, oDataDS, sFileName, oAnexoSet, oParentResponse, aUploadColletionItems, fI18n,
							iCount, sMessageAnexo);
					}
				});
		},
		uploadFileInDocumentService: function (that, oBlob, oDataDS, sFileName, oAnexoSet, oParentResponse, aUploadColletionItems, fI18n,
			iCount, sMessageAnexo) {
			DocumentService.uploadFile(oBlob, oDataDS.FolderId, that, sFileName).then(function (e) {
				if (e.message !== undefined) {
					that._addPopoverMessage("Error", fI18n.getText("PopTitle") + sMessageAnexo, e.message);
				} else {
					if (iCount < aUploadColletionItems.length) {
						var t = {
							PO_NUMBER: oAnexoSet.PO_NUMBER,
							RUC: oAnexoSet.RUC,
							FOLIO: oAnexoSet.FOLIO,
							FILENAME: sFileName
						};
						oAnexoSet.AnexoToFile.push(t);
					}
				}
				if (iCount === aUploadColletionItems.length - 1) {
					oDataService.consult(that, "create", "/AnexoSet", oAnexoSet, "").then(data => {
						that._addPopoverMessage("Success", fI18n.getText("PopTitle") + sMessageAnexo, "Anexos Guardados");
						BusyIndicator.hide();
					}).catch(err => {
						that._addPopoverMessage("Error", fI18n.getText("PopTitle") + sMessageAnexo, "Error al subir Anexos");
						BusyIndicator.hide();
						console.log(err);
					});
				}
				iCount++;
			});
		},
		xmlCompleteFields: function (that, oEvent, oDataValidation, bMasivo) {

		},
		getFiltersConstant: function () {
			var aFilterUser = [];
			aFilterUser.push(new Filter("Aplication", "EQ", "SCP_SUPPLIERS"));
			aFilterUser.push(new Filter("Group1", "EQ", "SHAREPOINT"));
			aFilterUser.push(new Filter("Field", "EQ", "URL"));
			aFilterUser.push(new Filter("Field", "EQ", "LANDSCAPE"));
			aFilterUser.push(new Filter("Field", "EQ", "ROOT_DIRECTORY"));
			aFilterUser.push(new Filter("Field", "EQ", "PRE_REGISTER"));
			aFilterUser.push(new Filter("Group1", "EQ", "XML_TAG"));
			aFilterUser.push(new Filter("Field", "EQ", "DOCUMENT_TYPE"));

			return aFilterUser;
		},
		xmlValidation: function (that, oEvent, oDataValidation, bMasivo, aTag, oRowSelected) {
			var sResultFile = oEvent.target.result;
			var a = oEvent.target.result;
			var bValid = true;
			var bError = false;
			var sTextI18n = "";
			var o = a.split("ï»¿");
			var oTag;
			var sTag = "";
			var sEtiquete = "";
			if (o.length === 2) {
				a = o[1];
			}

			if (sResultFile.includes("href=" + '"recibo.xsl"' + "")) {
				if (oDataValidation.tipodocumento === "01") {
					bValid = false;
					sTextI18n = "msgxmlnotbelonginvoice";
					//return MessageToast.show("XML no pertenece a una factura");
				}
			} else {
				if (oDataValidation.tipodocumento === "02") {
					bValid = false;
					sTextI18n = "msgxmlnotbelongreceipt";
					//return MessageToast.show("XML no pertenece a un Recibo");
				}
			}
			var i = that.getView().getModel("Usuario").getData();
			a = (new DOMParser).parseFromString(a, "text/xml");
			a = that.xmlToJson(a);
			$.each(aTag, function (k, v) {
				if (a[v.text] !== undefined) {
					oTag = a[v.text];
					sTag = v.id;
					sEtiquete = v.text;
				}
			});
			if (oTag === undefined) {
				bValid = false;
				sTextI18n = "msginvoicetagnotfound";
				//return MessageToast.show("Etiqueta Invoice no encontrado en el XML");
			}
			try {
				//Invoice
				if (oTag["cac:AccountingSupplierParty"]["cac:Party"]["cac:PartyIdentification"] !== undefined) {
					if (oTag["cac:AccountingSupplierParty"]["cac:Party"]["cac:PartyIdentification"]["cbc:ID"]["#text"] !== i.ruc && bValid) {
						bValid = false;
						sTextI18n = "msgrucnotmatch";
						//return MessageToast.show("RUC no concuerda con RUC asignado al usuario.");
					}
				} else if (oTag["cac:AccountingSupplierParty"]["cbc:CustomerAssignedAccountID"]["#text"] !== i.ruc && bValid) {
					bValid = false;
					sTextI18n = "msgrucnotmatch";
					//return MessageToast.show("RUC no concuerda con RUC asignado al usuario.");
				}
				//Invoice
				if (oTag["cbc:IssueDate"]["#text"] !== oDataValidation.fechaFactura && bValid && oRowSelected === undefined) {
					bValid = false;
					sTextI18n = "msginvoicedatenotmatch";
					//return MessageToast.show("Fecha de factura no concuerda con XML");
				}
				//Invoice
				if (oRowSelected !== undefined) {
					oRowSelected.FechaFacturaP = oTag["cbc:IssueDate"]["#text"];
				}
				//Invoice Número de factura
				if (oTag["cbc:InvoiceTypeCode"] !== undefined && oTag["cbc:ID"] !== undefined) {
					var n = oTag["cbc:ID"]["#text"];
					n = Formatter.formatoReferencia(n);
					if (n !== oDataValidation.numeroFactura && bValid && oRowSelected === undefined) {
						bValid = false;
						sTextI18n = "msginvoicenumbernotmatch";
						//return MessageToast.show("Número de Factura no concuerda con XML");
					}
					if (oRowSelected !== undefined) {
						oRowSelected.REFERENCE = n;
					}
				} else if (oTag["cbc:ID"] !== undefined) {
					var n = oTag["cbc:ID"]["#text"];
					n = Formatter.formatoReferencia(n);
					if (n !== oDataValidation.numeroFactura && bValid && oRowSelected === undefined) {
						bValid = false;
						sTextI18n = "msginvoicenumbernotmatch";
						//return MessageToast.show("Número de Factura no concuerda con XML");
					}
					if (oRowSelected !== undefined) {
						oRowSelected.REFERENCE = n;
					}
				} else if (sEtiquete === "Invoice" && bValid) {
					bValid = false;
					sTextI18n = "msgtagnotfoundinvoicetypecodeorid";
					//return MessageToast.show("Etiqueta cbc:InvoiceTypeCode ó cbc:ID no encontrada en XML");
				}
				//Nota de crédito documento de referencia

				/*			if (oTag["cac:BillingReference"] !== undefined && bValid) {
								if (oTag["cac:BillingReference"]["cac:InvoiceDocumentReference"] !== undefined) {
									if (oTag["cac:BillingReference"]["cac:InvoiceDocumentReference"]["cbc:DocumentTypeCode"] !== undefined) {
										if (oTag["cac:BillingReference"]["cac:InvoiceDocumentReference"]["cbc:ID"] !== undefined) {
											var InvoiceReference = oTag["cac:BillingReference"]
												["cac:InvoiceDocumentReference"]["cbc:ID"]["#text"];
											InvoiceReference = Formatter.formatoReferencia(InvoiceReference);
											if (InvoiceReference !== oDataValidation.numeroFactura && bValid && oRowSelected === undefined) {
												bValid = false;
												sTextI18n = "msginvoicenumbernotmatch";
												//return MessageToast.show("Número de Factura no concuerda con XML");
											}
											if (oRowSelected !== undefined) {
												oRowSelected.REFERENCE = InvoiceReference;
											}
										} else {
											bValid = false;
											sTextI18n = "msnNotFoundInvoiceReference";
										}
									}
								} else if (sEtiquete !== "Invoice") {
									bValid = false;
									sTextI18n = "msnNotFoundInvoiceReference";
								}
							} else if (sEtiquete !== "Invoice") {
								bValid = false;
								sTextI18n = "msnNotFoundInvoiceReference";
							}*/

				//Invoice
				if (oDataValidation.tipodocumento === "01" && !bMasivo) {
					oDataValidation.total = oDataValidation.TOTAL_VALUE_IGV.replace(/\s/g, "");
				} else if (!bMasivo) {
					oDataValidation.total = oDataValidation.TOTAL_VALUE_NO_IGV.replace(/\s/g, "");
				} else {
					oDataValidation.total = oDataValidation.total.replace(/\s/g, "");
				}
				//Invoice
				if (oTag["cac:RequestedMonetaryTotal"] === undefined) {
					if (parseFloat(oTag["cac:LegalMonetaryTotal"]["cbc:PayableAmount"]["#text"].replace(/,/g, "")) !== parseFloat(oDataValidation.total) &&
						bValid) {
						bValid = false;
						sTextI18n = "msginvoiceamountdifferent";
						//return MessageToast.show("Monto de factura es distinto a XML");
					}
				} else if (parseFloat(oTag["cac:RequestedMonetaryTotal"]["cbc:PayableAmount"]["#text"].replace(/,/g, "")) !== parseFloat(
						oDataValidation.total) &&
					bValid) {
					bValid = false;
					sTextI18n = "msginvoiceamountdifferent";
					//return MessageToast.show("Monto de factura es distinto a XML");
				}
				//Invoice
				if (oTag["cbc:DocumentCurrencyCode"] !== undefined) {
					if (oTag["cbc:DocumentCurrencyCode"]["#text"] !== "" && oTag["cbc:DocumentCurrencyCode"]["#text"] !==
						oDataValidation.moneda &&
						bValid) {
						bValid = false;
						sTextI18n = "msgcurrenctynotmatch";
						//return MessageToast.show("Moneda no concuerda con XML");
					}
				} else if (oTag["cac:TaxTotal"]["cbc:TaxAmount"]["@attributes"]["currencyID"] !== oDataValidation.moneda && bValid) {
					bValid = false;
					sTextI18n = "msgcurrenctynotmatch";
					//return MessageToast.show("Moneda no concuerda con XML");
				}

				return {
					"Valid": bValid,
					"TextI18n": sTextI18n,
					"Error": bError,
					"TextError": ""
				};
			} catch (err) {
				console.log(err);
				return {
					"Valid": bValid,
					"TextI18n": sTextI18n,
					"Error": true,
					"TextError": err.message
				};
				//return MessageToast.show(err.message);
			}

		}

	});
});