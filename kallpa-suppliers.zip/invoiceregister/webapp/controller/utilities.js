sap.ui.define(["./utilities"], function () {
	"use strict";
	return {
		_getLogonData: function () {
			return new Promise(function (e, t) {
				if (sap.ushell) {
					e(sap.ushell.Container.getUser().getId().toUpperCase())
				} else {
					t("Logon failed!")
				}
			})
		}
	}
});