sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"./utilities",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter"
], function (e, t, n, o, r, i, Filter) {
	"use strict";
	var s;
	return e.extend("com.everis.suppliers.invoiceregister.controller.DetalleOc", {
		onInit: function () {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getTarget("DetalleOc").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));
			this.oModel = this.getOwnerComponent().getModel()
		},
		handleRouteMatched: function (e) {
			this.getView().setModel(sap.ui.getCore().getModel("TipDoc"), "TipDoc");
			var oItemRoute = sap.ui.getCore().getModel("TipDoc").getData();
			var t = e.getParameter("data");
			var aFilters = [];
			var n = new sap.ui.model.Filter({
				path: "CLASEPEDIDO",
				operator: "EQ",
				value1: "0"
			});
			aFilters.push(new Filter({
				path: "CLASEPEDIDO",
				operator: "EQ",
				value1: "0"
			}));
			aFilters.push(new Filter({
				path: "DocTypeSunat",
				operator: "EQ",
				value1: oItemRoute.DocTypeSunat
			}));
			if (t.context) {
				this.fecha = t.date;
				this.reference = t.reference;
				this.sContext = t.context;
				if (this.sContext) {
					var o = {
						path: "/" + this.sContext,
						filters: aFilters
					};
					this.getView().bindObject(o);
				}
			}
			var r = this.getView().byId("Detalle");
			var i = this.getView().getModel("TipDoc");
			if (i.getData().TipDoc === "02") {
				r.getColumns()[6].setVisible(false);
				r.getColumns()[7].setVisible(true)
			} else {
				r.getColumns()[6].setVisible(true);
				r.getColumns()[7].setVisible(false)
			}
			var s = r.getBinding("items");
			s.filter(aFilters);
			this.addMsg()
		},
		addMsg: function () {
			if (this.getOwnerComponent().getModel("oMsg")) {
				var e = this.getOwnerComponent().getModel("oMsg").arreglo;
				for (var t = 0; t < e.length; t++) {
					this._addPopoverMessage(e[t].type, e[t].title, e[t].msg)
				}
			}
		},
		_updatePopoverCounter: function () {
			$._popoverCount = $._popoverCount + 1;
			if (this.getView()) {
				this.getView().byId("popoverButton").setText("Mensajes (" + $._popoverCount + ")")
			}
		},
		_addPopoverMessage: function (e, t, n) {
			$._popoverData.push({
				type: e,
				title: t,
				description: n
			});
			$._popoverModel.setData($._popoverData);
			this._updatePopoverCounter()
		},
		onListUpdateFinishedPosition: function () {
			var e = this.getView().byId("Detalle");
			var t = [];
			var n = e.getItems();
			var o = true;
			var r = [];
			var i = {};
			var s = this.getOwnerComponent().getModel("oDetalleArr");
			var a = this;
			if (s) {
				var l = a.getOwnerComponent().getModel("oDetalleArr");
				r = l.arreglo;
				for (var g = 0; g < r.length; g++) {
					if (n[0].getBindingContext().getObject().PO_NUMBER) {
						if (n[0].getBindingContext().getObject().PO_NUMBER === r[g]) {
							o = false;
							if (o) {
								r.push(n[0].getBindingContext().getObject().PO_NUMBER);
								i.arreglo = r;
								a.getOwnerComponent().setModel(i, "oDetalleArr")
							}
						}
					}
				}
			}
			for (var g = 0; g < n.length; g++) {
				t.push(n[g].getBindingContext().getObject())
			}
			if (this.getOwnerComponent().getModel("oDetallePO")) {
				var u = this.getOwnerComponent().getModel("oDetallePO");
				var d = JSON.parse(u.getJSON());
				var h = d.arreglo;
				for (g = 0; g < h.length; g++) {
					t.push(h[g])
				}
			}
			var f = {};
			f.arreglo = t;
			var c = new sap.ui.model.json.JSONModel(f);
			this.getOwnerComponent().setModel(c, "oDetallePO");
			if (this.getOwnerComponent().getModel("oDetallePO")) {
				u = this.getOwnerComponent().getModel("oDetallePO");
				d = JSON.parse(u.getJSON());
				this.oInfoPO_ = d
			}
		},
		onSelectionChange: function () {
			s = this.getView().getModel("i18n").getResourceBundle();
			var e = this.getView().byId("Detalle");
			var t = [];
			var n = e.getSelectedItems();
			var o = e.getItems();
			var i = o[0].getBindingContext().getObject().PO_NUMBER;
			if (n.length < 1) {
				r.show(s.getText("Empty1") + i);
				e.selectAll()
			}
			if (n.length === o.length) {
				n = []
			}
			for (var a = 0; a < n.length; a++) {
				t.push(n[a].getBindingContext().getObject())
			}
			if (this.getOwnerComponent().getModel("oDetallePO")) {
				var l = this.getOwnerComponent().getModel("oDetallePO");
				var g = JSON.parse(l.getJSON());
				var u = g.arreglo;
				for (a = 0; a < u.length; a++) {
					if (u[a].PO_NUMBER !== i) {
						t.push(u[a])
					}
				}
			}
			var d = {};
			d.arreglo = t;
			var h = new sap.ui.model.json.JSONModel(d);
			this.getOwnerComponent().setModel(h, "oDetallePO");
			if (this.getOwnerComponent().getModel("oDetallePO")) {
				l = this.getOwnerComponent().getModel("oDetallePO");
				g = JSON.parse(l.getJSON())
			}
		},
		_onPageNavButtonPress: function () {
			var e = o.getInstance();
			var t = e.getPreviousHash();
			var n = this.getQueryParameters(window.location);
			if (t !== undefined || n.navBackToLaunchpad) {
				window.history.go(-1)
			} else {
				var r = sap.ui.core.UIComponent.getRouterFor(this);
				r.navTo("default", true)
			}
		},
		getQueryParameters: function (e) {
			var t = {};
			var n = e.search.substring(1).split("&");
			for (var o = 0; o < n.length; o++) {
				var r = n[o].split("=");
				t[r[0]] = decodeURIComponent(r[1])
			}
			return t
		},
		_onButtonPress: function (e) {
			e = jQuery.extend(true, {}, e);
			return new Promise(function (e) {
				e(true)
			}).then(function (t) {
				var n = e.getSource().getBindingContext();
				return new Promise(function (e) {
					this.doNavigate("CabeceraOc", n, e, "")
				}.bind(this))
			}.bind(this)).then(function (e) {
				if (e === false) {
					return false
				} else {
					var t = this.getView();
					var n = this;
					return new Promise(function (e, o) {
						var r = n.oModel;
						var i = function (e) {
							r.resetChanges();
							o(new Error(e))
						};
						if (r && r.hasPendingChanges()) {
							r.submitChanges({
								success: function (o) {
									var s = o.__batchResponses[0];
									var a = s.__changeResponses && s.__changeResponses[0];
									if (a && a.data) {
										var l = r.getKey(a.data);
										t.unbindObject();
										t.bindObject({
											path: "/" + l
										});
										if (window.history && window.history.replaceState) {
											window.history.replaceState(undefined, undefined, window.location.hash.replace(encodeURIComponent(n.sContext),
												encodeURIComponent(l)))
										}
										r.refresh();
										e()
									} else if (a && a.response) {
										i(a.message)
									} else if (!a && s.response) {
										i(s.message)
									} else {
										r.refresh();
										e()
									}
								},
								error: function (e) {
									o(new Error(e.message))
								}
							})
						} else {
							e()
						}
					})
				}
			}.bind(this)).then(function (e) {
				if (e === false) {
					return false
				} else {
					return new Promise(function (e) {
						var t = "";
						t = t === "default" ? undefined : t;
						sap.m.MessageToast.show("Pre-Registro Exitoso", {
							onClose: e,
							duration: 0 || 3e3,
							at: t,
							my: t
						})
					})
				}
			}.bind(this)).catch(function (e) {
				if (e !== undefined) {
					t.error(e.message)
				}
			})
		},
		doNavigate: function (e, t, n, o) {
			var r = t ? t.getPath() : null;
			var i = t ? t.getModel() : null;
			var s;
			if (r !== null && r !== "") {
				if (r.substring(0, 1) === "/") {
					r = r.substring(1)
				}
				s = r.split("(")[0]
			}
			var a;
			var l = this.sMasterContext ? this.sMasterContext : r;
			if (s !== null) {
				a = o || this.getOwnerComponent().getNavigationPropertyForNavigationWithContext(s, e)
			}
			if (a !== null && a !== undefined) {
				if (a === "") {
					this.oRouter.navTo(e, {
						context: r,
						masterContext: l
					}, false)
				} else {
					i.createBindingContext(a, t, null, function (t) {
						if (t) {
							r = t.getPath();
							if (r.substring(0, 1) === "/") {
								r = r.substring(1)
							}
						} else {
							r = "undefined"
						}
						if (r === "undefined") {
							this.oRouter.navTo(e)
						} else {
							this.oRouter.navTo(e, {
								context: r,
								masterContext: l
							}, false)
						}
					}.bind(this))
				}
			} else {
				this.oRouter.navTo(e)
			}
			if (typeof n === "function") {
				n()
			}
		},
		_onButtonPress1: function (e) {
			e = jQuery.extend(true, {}, e);
			return new Promise(function (e) {
				e(true)
			}).then(function (t) {
				var n = e.getSource().getBindingContext();
				return new Promise(function (e) {
					this.doNavigate("CabeceraOc", n, e, "")
				}.bind(this))
			}.bind(this)).then(function (e) {
				if (e === false) {
					return false
				} else {
					return new Promise(function (e) {
						var t, n;
						var o = this.oModel;
						if (o && o.hasPendingChanges()) {
							t = Object.keys(o["mChangedEntities"]);
							for (var r = 0; r < t.length; r++) {
								n = o.getContext("/" + t[r]);
								if (n && n.bCreated) {
									o.deleteCreatedEntry(n)
								}
							}
							o.resetChanges()
						}
						e()
					}.bind(this))
				}
			}.bind(this)).then(function (e) {
				if (e === false) {
					return false
				} else {
					return new Promise(function (e) {
						var t = "";
						t = t === "default" ? undefined : t;
						sap.m.MessageToast.show("No Guardado", {
							onClose: e,
							duration: 0 || 3e3,
							at: t,
							my: t
						})
					})
				}
			}.bind(this)).catch(function (e) {
				if (e !== undefined) {
					t.error(e.message)
				}
			})
		},

		formatNumber: function (e) {
			jQuery.sap.require("sap.ui.core.format.NumberFormat");
			var t = new sap.ui.core.Locale("en-US");
			var n = {
				minIntegerDigits: 3,
				minFractionDigits: 2,
				maxFractionDigits: 2
			};
			var o = sap.ui.core.format.NumberFormat.getFloatInstance(n, t);
			return o.format(e).replace(/^\b0+\B/, "")
		},
		_handleMessagePopoverPress: function (e) {
			if (!$._oMessagePopover.isOpen()) {
				$._oMessagePopover.openBy(e.getSource())
			} else {
				$._oMessagePopover.close()
			}
		}
	})
}, true);