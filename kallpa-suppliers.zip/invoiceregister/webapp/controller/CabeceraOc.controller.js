sap.ui.define(["../controller/BaseController",
	"sap/m/MessageBox",
	"./utilities",
	"sap/ui/core/routing/History",
	"../controller/utilities",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/export/Spreadsheet",
	"../model/formatter",
	"sap/ui/model/Sorter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/m/BusyDialog",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/UploadCollection",
	"../model/DocumentService",
	"../util/xml",
	"../service/oData",
	"sap/ui/core/BusyIndicator",
	"../service/SharePoint",

], function (BaseController, MessageBox, a, r, o, MessageToast, i, n, l, c, u, JSONModel, g, f, v, h, p, E, xmljs, oDataService,
	BusyIndicator, SharePoint) {
	"use strict";
	$._oMessageTemplate = new sap.m.MessagePopoverItem({
		type: "{type}",
		title: "{title}",
		description: "{description}",
		subtitle: "{subtitle}",
		counter: "{counter}"
	});
	$._oMessagePopover = new sap.m.MessagePopover({
		items: {
			path: "/",
			template: $._oMessageTemplate
		}
	});
	$._popoverData = [];
	$._popoverCount = 0;
	$._popoverModel = new sap.ui.model.json.JSONModel;
	var m;
	var b;
	var sUri = "",
		sAmbient = "",
		sProject = "",
		sTypeRepository = "SHAREPOINT", //Textos validos son, DOCUMENTSERVICE y SHAREPOINT
		sRouteDialog = "com.everis.suppliers.invoiceregister.view.dialog",
		aTag = [];

	return BaseController.extend("com.everis.suppliers.invoiceregister.controller.CabeceraOc", {
		formatter: c,
		onInit: function () {
			var that = this;
			that.uri = sUri;
			this.oModel = this.getOwnerComponent().getModel();
			//this._byId("smartFilterBar")._oSearchButton.setText(this.getI18nText("txtbtnsearch"));
			var t = new JSONModel({
				tableMode: "SingleSelectLeft"
			});
			that.getView().setModel(t, "EventosModel");
			that.getView().getModel("EventosModel").updateBindings();
			this.oCboIndexuno = "0";
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oModel = this.getOwnerComponent().getModel();
			$._popoverModel.setData($._popoverData);
			$._oMessagePopover.setModel($._popoverModel);
			this.oCbo = [];
			this.bFlagEstateView = true;
			this.oRules = new Object;
			var a = new JSONModel({
				Registro: []
			});
			this.getView().setModel(a, "UploadModel");
			/*BusyIndicator.show(0);
			SharePoint.getToken(this).then(resolve => {
				that.bearer = resolve.access_token;
				BusyIndicator.hide();
			}).catch(err => {
				console.log(err);
			});*/

		},
		onAfterRendering: function (e) {
			var that = this;
			this.byId("POHeaderTable").setSticky(["ColumnHeaders", "HeaderToolbar"]);
			this._BusyDialog = new f({
				cancelButtonText: "Aceptar",
				title: "Verificando Usuario",
				customIcon: "none",
				showCancelButton: false
			});
			this._BusyDialog.open();
			this._BusyDialog.attachClose("", function (e) {
				if (e.getParameters().cancelPressed) {
					window.history.go(-1);
				}
			});
			//	this.readUserApiInfo().then(function (e) {
			this.readUserIasInfo().then(function (oUserModel) {
				oUserModel.getData().company = "0001";
				that.getView().setModel(oUserModel, "Usuario");
				that.oModel.read("/ContactSet(Ruc='" + oUserModel.getData().ruc + "',Sociedad='" + oUserModel.getData().company + "',Dni='')", {
					success: function (e, t) {
						E.setCmisId(e.Root);
						let r = {
							folder: e.Folder,
							FolderId: e.FolderId
						};
						//Document Service
						that.getView().setModel(new JSONModel(r), "documentService");
						if (e.Partner1 !== "" || e.Partner1 !== undefined) {
							var o = [];
							var s = that._byId("idCmbFecha").getSelectedKey();
							var sCode = that._byId("idCmbDocumentType").getSelectedKey();
							var l = that.fechaFiltro(s, "idCmbFecha");
							o.push(new i({
								path: "ItTaxIdNumber",
								operator: n.EQ,
								value1: e.Ruc
							}));
							o.push(new i({
								path: "ItCompanyId",
								operator: n.EQ,
								value1: e.Sociedad
							}));
							o.push(new i({
								path: "ClasePedido",
								operator: n.EQ,
								value1: "0"
							}));
							o.push(new i({
								path: "FECHA_FACTURA",
								operator: "GE",
								value1: l.startDate
							}));
							o.push(new i({
								path: "DocTypeSunat",
								operator: "EQ",
								value1: sCode
							}));
							that.getView().setModel(new JSONModel(e), "Contacto");
							var c = that.getView().byId("POHeaderTable");
							c._getSelectAllCheckbox().setEnabled(false);
							var u = c.getBinding("items");
							u.filter(new i({
								filters: o,
								and: true
							}));

							that.getDocumentTypeForTable(that, sCode);
							that._BusyDialog.close();
						}
						that._BusyDialog.setShowCancelButton(true);
					},
					error: function (e) {
						that._BusyDialog.setText("Error al verificar usuario");
						that._BusyDialog.setShowCancelButton(true);
					}
				});
			});

			BusyIndicator.show(0);
			//Se obtiene el token
			oDataService.consult(that, "read", "/SPTokenSet('INVOICE')", "", "").then(response => {
				BusyIndicator.hide();
				that.bearer = response.Token;
				if (response.Token.length === 0) {
					MessageBox.error(that.getI18nText("msgNotToken"));
				}

			}).catch(err => {
				console.log(err);
			});

			//Se obtiene las costantes para guardar los archivos
			var aFilters = that.getFiltersConstant();
			oDataService.consult(that, "read", "/ConfigurationSet", "", aFilters).then(response => {
				response = response.results;
				//Se obtiene la url
				sUri = response.find(oItem => {
					return oItem.Group1 === "SHAREPOINT" && oItem.Field === "URL";
				});
				if (sUri === undefined) {
					MessageBox.error(that.getI18nText("msgNotUrl"));
				} else {
					sUri = sUri.ValueLow;
					that.uri = sUri;
				}
				//Se obtiene la ruta de almacenamiento de archivos
				sAmbient = response.find(oItem => {
					return oItem.Group1 === "SHAREPOINT" && oItem.Field === "LANDSCAPE";
				});
				if (sAmbient === undefined) {
					MessageBox.error(that.getI18nText("msgNotRouteFolder"));
				} else {
					sAmbient = sAmbient.ValueLow;
				}
				//Se obtiene la ruta de almacenamiento de archivos
				var sValue = response.find(oItem => {
					return oItem.Group1 === "SHAREPOINT" && oItem.Field === "ROOT_DIRECTORY";
				});
				if (sValue === undefined) {
					MessageBox.error(that.getI18nText("msgNotRouteFolder"));
				} else {
					SharePoint.setValueRoot(sValue.ValueLow);
				}
				//Se obtiene la ruta de almacenamiento de archivos
				sProject = response.find(oItem => {
					return oItem.Group1 === "SHAREPOINT" && oItem.Field === "PRE_REGISTER";
				});
				if (sValue === undefined) {
					MessageBox.error(that.getI18nText("msgNotRouteFolder"));
				} else {
					sProject = sProject.ValueLow;
				}
				var aXmlTag = response.filter(oItem => {
					return oItem.Group1 === "XML_TAG" && oItem.Field === "DOCUMENT_TYPE";
				});

				for (var i = 0; i < aXmlTag.length; i++) {
					var oXmlTag = aXmlTag[i];
					aTag.push({
						"id": oXmlTag.ValueLow,
						"text": oXmlTag.ValueHigh
					});
				}

			}).catch(err => {
				console.log(err);
			});
		},
		getDocumentTypeForTable: function (that, sCode) {
			var aFilter = [];
			aFilter.push(new i({
				path: "Codigo",
				operator: "EQ",
				value1: sCode
			}));
			aFilter.push(new i({
				path: "Filter",
				operator: "EQ",
				value1: false
			}));
			oDataService.consult(that, "read", "/DocumentTypeSet", "", aFilter).then(response => {
				BusyIndicator.hide();
				response = response.results;
				that.getModel("ModelGlobal").setProperty("/DocumentType", response);
				that.getModel("ModelGlobal").refresh(true);
			}).catch(err => {
				console.log(err);
			});
		},
		onColumns: function () {
			var e = this._getSmartTable();
			if (e) {
				e.openPersonalisationDialog("Columns");
			}
		},
		addMsg: function () {
			var e = this.getOwnerComponent().getModel("oMsg").arreglo;
			for (var t = 0; t < e.length; t++) {
				this._addPopoverMessage(e[t].type, e[t].title, e[t].msg);
			}
		},
		_handleMessagePopoverPress: function (e) {
			if (!$._oMessagePopover.isOpen()) {
				$._oMessagePopover.openBy(e.getSource());
			} else {
				$._oMessagePopover.close();
			}
		},
		_updatePopoverCounter: function () {
			$._popoverCount = $._popoverCount + 1;
			if (this.getView()) {
				this.getView().byId("popoverButton").setText("Mensajes (" + $._popoverCount + ")");
			}
		},
		_addPopoverMessage: function (e, t, a) {
			$._popoverData.unshift({
				type: e,
				title: t,
				description: a
			});
			$._popoverModel.setData($._popoverData);
			this._updatePopoverCounter();
		},
		total: 0,
		onSelectCheckbox: function (oEvent) {
			var that = this;
			var oSource = oEvent.getSource();
			var sCustom = oSource.data("custom");
			var t = oEvent.getSource();
			var a = t.getSelected();
			switch (sCustom) {
			case 'masive':
				if (a) {
					this.getView().getModel("EventosModel").setProperty("/tableMode", "MultiSelect");
				} else {
					this.getView().getModel("EventosModel").setProperty("/tableMode", "SingleSelectLeft");
					this._byId("POHeaderTable").removeSelections();
				}
				var r = this._byId("POHeaderTable");
				var o = r.getSelectedItems();
				this.total = 0;
				var s = oSource.getModel("UploadModel");
				var i = s.getData().Registro.findIndex(e => e.DN_NUMBER === "Masivo" && e.PO_NUMBER === "Masivo");
				if (i >= 0) {
					s.getData().Registro.splice(i, 1);
					s.refresh();
				}
				var n = r.getItems();
				var s = oSource.getModel("UploadModel");
				if (a) {
					r._getSelectAllCheckbox().setEnabled(true);
					for (var l in n) {
						//Duro
						n[l].getCells()[8].setValue("");
						n[l].getCells()[9].setValue("");
						n[l].getCells()[10].setValue("");
					}
					s.setProperty("/Registro", []);
				} else {
					r._getSelectAllCheckbox().setEnabled(false);
					for (var g in n) {
						n[g].getMultiSelectControl().setSelected(false);
					}
				}
				that.getModel("ModelGlobal").setProperty("/Masive", a);
				break;
			case 'electronicsupplier':
				that.getModel("ModelGlobal").setProperty("/ElectronicSupplier", a);
				break;
			default:
			}

		},
		enableAllTable: function () {
			var that = this;
			var e = this._byId("POHeaderTable");
			var t = e.getItems();
			var a = e.getSelectedItems();
			that.getModel("ModelGlobal").setProperty("/Masive", false);
		},
		onSelectionChangeTable: function (e) {
			var t = this;
			var that = this;
			var reader = new FileReader;
			var r = e.getSource().getId();
			var o = this._byId("chkMASIVO").getSelected();
			var bChkMASIVO = this._byId("chkMASIVO").getSelected();
			var bElectronicSupplier = this.getModel("ModelGlobal").getProperty("/ElectronicSupplier");
			var i = "";
			if (!e.getParameters().listItem.getSelected()) {
				var n = e.getParameters().listItem.getCells();
				if (!o) {
					//duro
					n[7].setEnabled(true);
					n[8].setEnabled(true);
					n[9].setEnabled(true);
					n[10].setEnabled(true);
					n[11].setEnabled(true);
				}
				return;
			} else {
				if (!bChkMASIVO) {
					this.enableAllTable();
					this.oRules = e.getParameters().listItem.getBindingContext().getObject();
					if (this.oRules.REFERENCE === "" && (this.oRules.FechaFacturaP === null || this.oRules.FechaFacturaP === "") && this.oRules.HEADER_TEXT ===
						"") {
						e.getParameters().listItem.setSelected(false);
						return MessageToast.show("Ingrese Número de Factura, Fecha, texto de cabecera");
					} else {
						if (this.oRules.REFERENCE === "") {
							if (i === "") {
								i = "Ingrese Número de factura";
							}
						} else if (this.oRules.FechaFacturaP === null) {
							if (i === "") {
								i = "Ingrese fecha factura";
							} else {
								i = i.concat(", fecha factura")
							}
						} else if (this.oRules.HEADER_TEXT === "") {
							if (i === "") {
								i = "Ingrese texto de cabecera";
							} else {
								i = i.concat(", texto de cabecera")
							}
						}
						if (i !== "") {
							e.getParameters().listItem.setSelected(false);
							return MessageToast.show(i);
						}
					}
					var l = this.getView().getModel();
					var u = this.getView().getModel("Usuario").getData();
					var d = u.company;
					var g = t.oRules.TIPDOCREFERENCE + "-" + t.oRules.REFERENCE;
					return new Promise(function (e, t) {
						l.read("/InvoiceNumberSet(Numfactura='" + g + "',Bukrs='" + d + "')", {
							success: function (t) {
								e(t.Message)
							},
							error: function (e) {
								t("Error")
							}
						})
					}).then(function (e) {
						/*var sPath = that.oModel.createKey("/ReferenceSet", {
							Xblnr: u,
							Nif: d
						});
						oDataService.consult(that, "read", sPath, "", "").then(response => {
							BusyIndicator.hide();
							that.invoiceAlreadyRegistered(that, response, a, l);
						}).catch(err => {
							console.log(err);
						});*/
						var r = t.getView().getModel("UploadModel");
						var o = r.getData();
						o = o.Registro.filter(e => e.DN_NUMBER === t.oRules.DN_NUMBER && e.PO_NUMBER === t.oRules.PO_NUMBER);
						if (o.length === 0) {
							r.getData().Registro.push({
								DN_NUMBER: t.oRules.DN_NUMBER,
								PO_NUMBER: t.oRules.PO_NUMBER,
								uploadCollection: [],
								blobs: [],
								xml: {
									name: ""
								},
								pdf: {
									name: ""
								}
							});
							r.refresh();
							o = r.getData().Registro
						}
						if (o[0].xml.name === "" && bElectronicSupplier) {
							return MessageBox.error(that.getI18nText("msgAttachmentInvoiceXml"));
						} else if (o[0].pdf.name === "" && !bElectronicSupplier) {
							return MessageBox.error(that.getI18nText("msgAttachmentInvoicePdf"));
						}
						r.refresh();
						if (t.onValidateFormatoNFactura(g)) {
							var oFileXml = o[0].xml.file;
							var aFile = [];
							aFile.push(oFileXml);
							aFile.push(o[0].pdf.file);
							//var oFileXml = o[0].blobs.filter(e => e.type === "text/xml");
							if (xmljs.onValidationAdjunt(aFile)) {
								t.byId("POHeaderTable").getSelectedItem().setSelected(false);
							} else {
								reader.onload = function (oEvent) {
									var oDataValidation = Object.assign({}, t.oRules);
									oDataValidation.tipodocumento = oDataValidation.TIPDOCREFERENCE;
									oDataValidation.fechaFactura = oDataValidation.FechaFacturaP;
									oDataValidation.moneda = oDataValidation.CURRENCY;
									oDataValidation.numeroFactura = oDataValidation.REFERENCE;
									var oXmlValidation = that.xmlValidation(that, oEvent, oDataValidation, false, aTag);
									if (oXmlValidation.Error) {
										that.byId("POHeaderTable").getSelectedItem().setSelected(false);
										return MessageBox.error(oXmlValidation.TextError);
									} else if (!oXmlValidation.Valid) {
										that.byId("POHeaderTable").getSelectedItem().setSelected(false);
										return MessageBox.error(that.getI18nText(oXmlValidation.TextI18n));
									}

									var l = t.byId("POHeaderTable").getSelectedItem().getCells();
									//Duro
									l[7].setEnabled(false);
									l[8].setEnabled(false);
									l[9].setEnabled(false);
									l[10].setEnabled(false);
									l[11].setEnabled(false);
									i = o.ruc + "-" + g;
									t.getView().setModel(i, "referencia")
								};
								reader.onerror = function (e) {
									MessageToast.show("Error al leer documento XML")
								};
								reader.readAsBinaryString(oFileXml)
							}
						} else {
							if (o[0].pdf.name === "" && !bElectronicSupplier) {
								return MessageBox.error(that.getI18nText("msgAttachmentInvoicePdf"));
							}
							var h = t.getView().getModel("Usuario").getData();
							var p = h.ruc + "-" + g;
							t.getView().setModel(p, "referencia")
						}
					})
				}
			}
		},
		onChangeType: function (e) {},
		deleteDuplicates: function (e) {
			return e.reduce(function (e, t) {
				var a = [t.PO_NUMBER, t.DnNumber, t.ITEMNUMBER, t.LINENUMBER].join("|");
				if (e.temp.indexOf(a) === -1) {
					e.out.push(t);
					e.temp.push(a)
				}
				return e
			}, {
				temp: [],
				out: []
			}).out
		},
		onValidateDate: function (e) {
			var t = e.getParameter("valid");
			if (!t) {
				e.getSource().setValue("");
				return MessageToast.show("Fecha Incorrecta.")
			}
		},
		onReferenceChange: function (e) {
			try {
				var that = this;
				var oSource = e.getSource();
				var aCells = oSource.getParent().getCells();
				var r = oSource.getValue().toUpperCase().replace(/\s/g, "");
				var o = r.split("-");
				var i = o.join("");
				var n = "";
				//	var l = oSource.getParent().getCells()[6];
				var l = aCells.find(oItem => oItem.data("custom") === "selectDocumentType");
				if (l === undefined) {
					n = oSource.getParent().getCells()[0].getSelectedKey();
				} else {
					n = aCells.find(oItem => oItem.data("custom") === "selectDocumentType").getSelectedKey();
					//n = oSource.getParent().getCells()[6].getSelectedKey();
				}
				var u = "";
				var d = this.getView().getModel("Usuario").getData().ruc;
				//Casapalca es EE
				//var g = this.getView().getModel("Contacto").getData().Legalenty === "EE" ? true : false;
				var g = this.getModel("ModelGlobal").getProperty("/ElectronicSupplier");
				if (o.length === 2 && o[0].length == 4) {
					if (!/[^a-zA-Z0-9]/.test(i)) {
						if (/[a-zA-Z]/.test(i) && !g) {
							oSource.setValue("");
							return MessageBox.error(that.getI18nText("msgFormatForElectronicSupplier") + o[0]);
						}
						if (g) {
							if (!this.onValidateFormatoNFactura(o[0])) {
								return MessageToast.show("Proveedor registrado como emisor electrónico, por favor ingrese una factura electrónica.");
							}
						}
						u = n + "-" + c.formatoReferencia(r);
						BusyIndicator.show(0);
						var sPath = that.oModel.createKey("/ReferenceSet", {
							Xblnr: u,
							Nif: d
						});
						oDataService.consult(that, "read", sPath, "", "").then(response => {
							BusyIndicator.hide();
							that.invoiceAlreadyRegistered(that, response, oSource, l);
						}).catch(err => {
							console.log(err);
						});
						oSource.setValue(c.formatoReferencia(r))
					} else {
						return MessageToast.show("No se permiten caracteres especiales");
					}
				} else {
					var sFormat = that.getI18nText("msgFormatInvoice");
					var sStructureFormat = "";
					if (g) {
						sStructureFormat = that.getI18nText("plhStrucInvElectronic");
					} else {
						sStructureFormat = that.getI18nText("plhStrucInvNoElectronic");
					}
					//return MessageToast.show("N° Factura: Formato esperado FXXX-XXXXXXX");
					return MessageBox.error(sFormat + " " + sStructureFormat);
				}
			} catch (err) {
				MessageToast.show(err);
			}

		},
		clearTable: function () {
			var e = this._byId("POHeaderTable");
			var t = e.getSelectedItems();
			var a = this._byId("chkMASIVO");
			var r = e.getItems();
			a.setSelected(false);
			e._selectAllCheckBox.setSelected(false);
			e._getSelectAllCheckbox().setEnabled(false);
			var oUploadModel = this.getView().getModel("UploadModel");
			for (var s in t) {
				//Duro
				t[s].getCells()[8].setValue("");
				t[s].getCells()[9].setValue("");
				t[s].getCells()[10].setValue("");
				if (t[s].getMultiSelectControl() !== undefined) {
					t[s].getMultiSelectControl().setSelected(false);
				}
				//Duro
				t[s].getCells()[7].setEnabled(true);
				t[s].getCells()[8].setEnabled(true);
				t[s].getCells()[9].setEnabled(true);
				t[s].getCells()[10].setEnabled(true);
				t[s].getCells()[11].setEnabled(true);
			}
			this.getModel("ModelGlobal").setProperty("/Masive", false);
			this.getModel("ModelGlobal").setProperty("/ElectronicSupplier", true);
			this.getView().getModel("EventosModel").setProperty("/tableMode", "SingleSelectLeft");
			oUploadModel.setProperty("/Registro", []);
			oUploadModel.refresh();
			e.removeSelections();
		},
		onDialogMCancel: function (e) {
			this.getView().getModel("EventosModel").setProperty("/tableMode", "SingleSelectLeft");
			this.getView().getModel("EventosModel").updateBindings();
			this.getModel("ModelGlobal").setProperty("/Masive", false);
			this.clearTable();

			var t = e.getSource().getParent();
			t.close();
		},
		onDialogMOk: function (e) {
			var that = this;
			var reader = new FileReader;
			var r = this.getView().getModel("Masivo").getData();
			var o = this._byId("POHeaderTable");
			var i = o.getSelectedItems();
			var n = this.getView().getModel("Usuario").getData();
			var l = this.getView().getModel();
			var bElectronicSupplier = this.getModel("ModelGlobal").getData().ElectronicSupplier;
			var u = "";
			var d = sap.ui.getCore().byId("idMasivoDialog--idTablaMasivo");
			for (var g in r) {
				if (r[g].numeroFactura === "" && r[g].fechaFactura === "" && r[g].textoCabecera === "") {
					return MessageToast.show("Complete los campos Número de factura, fecha factura y texto de cabecera");
				} else {
					//if (!that.onValidaNumeroFactura(d.getVisibleItems()[0].getCells()[1])) {
					if (!that.onValidaNumeroFactura(d.getItems()[0].getCells()[1])) {
						return
					}
					if (r[g].numeroFactura === "") {
						if (u === "") {
							u = "Complete campo Número de factura"
						}
					}
					if (r[g].fechaFactura === "") {
						if (u === "") {
							u = "Complete campo fecha factura"
						} else {
							u = u.concat(", fecha factura")
						}
					}
					if (r[g].textoCabecera === "") {
						if (u === "") {
							u = "Complete campo texto de cabecera"
						} else {
							u = u.concat(", texto de cabecera")
						}
					}
					if (u !== "") {
						return MessageToast.show(u)
					}
				}
			}
			for (var f in i) {
				var aCells = i[f].getCells();
				aCells.find(oItem => oItem.data("custom") === "selectDocumentType").setSelectedKey(r[0].tipodocumento);
				//i[f].getCells()[6].setSelectedKey(r[0].tipodocumento);
				if (r[0].tipodocumento === "01") {
					var sTxtTotalValue = aCells.find(oItem => oItem.data("custom") === "txtTotalValueIgv").getText();
					aCells.find(oItem => oItem.data("custom") === "txtTotalValue").setText(sTxtTotalValue);
					//i[f].getCells()[4].setText(i[f].getCells()[13].getText())
				} else {
					var sTxtTotalNoValue = aCells.find(oItem => oItem.data("custom") === "txtTotalValueNoIgv").getText();
					aCells.find(oItem => oItem.data("custom") === "txtTotalValue").setText(sTxtTotalNoValue);
					//i[f].getCells()[4].setText(i[f].getCells()[12].getText())
				}
				/*i[f].getCells()[7].setValue(r[0].numeroFactura);
				i[f].getCells()[8].setValue(r[0].fechaFactura);
				i[f].getCells()[9].setValue(r[0].textoCabecera);*/
				aCells.find(oItem => oItem.data("custom") === "inputReference").setValue(r[0].numeroFactura);
				aCells.find(oItem => oItem.data("custom") === "dateInvoiceDate").setValue(r[0].fechaFactura);
				aCells.find(oItem => oItem.data("custom") === "inputHeader").setValue(r[0].textoCabecera);

			}
			var sInvoiceNumber = r[0].tipodocumento + "-" + r[0].numeroFactura;
			return new Promise(function (e, t) {
				var a = n.company;
				l.read("/InvoiceNumberSet(Numfactura='" + sInvoiceNumber + "',Bukrs='" + a + "')", {
					success: function (t) {
						e(that.Message);
					},
					error: function (e) {
						t("Error");
					}
				})
			}).then(function (e) {
				var aDataMasivo = that.getView().getModel("Masivo").getData();
				var o = that.getView().getModel("Usuario").getData();
				var i = that.getView().getModel("UploadModel");
				var n = i.getData();
				n = n.Registro.filter(e => e.DN_NUMBER === "Masivo" && e.PO_NUMBER === "Masivo");
				if (n.length === 0) {
					i.getData().Registro.push({
						DN_NUMBER: "Masivo",
						PO_NUMBER: "Masivo",
						uploadCollection: [],
						blobs: [],
						xml: {
							name: ""
						},
						pdf: {
							name: ""
						}
					});
					i.refresh();
					n = i.getData().Registro;
				}
				/*if (n[0].blobs.length === 0) {
					return MessageToast.show("Es necesario adjuntar un archivo");
				}*/
				if (n[0].xml.name === "" && bElectronicSupplier) {
					return MessageBox.error(that.getI18nText("msgAttachmentInvoiceXml"));
				} else if (n[0].pdf.name === "" && !bElectronicSupplier) {
					return MessageBox.error(that.getI18nText("msgAttachmentInvoicePdf"));
				}
				l.refresh();
				if (that.onValidateFormatoNFactura(r[0].numeroFactura)) {
					//var oFileXml = n[0].xml.filter(e => e.type === "text/xml");
					var oFileXml = n[0].xml.file;
					var aFile = [];
					aFile.push(oFileXml);
					aFile.push(n[0].pdf.file);
					if (!xmljs.onValidationAdjunt(aFile)) {
						reader.onload = function (oEvent) {
							var oDataValidation = Object.assign({}, aDataMasivo[0]);
							var oXmlValidation = that.xmlValidation(that, oEvent, oDataValidation, true, aTag);
							if (oXmlValidation.Error) {
								return MessageBox.error(oXmlValidation.TextError);
							} else if (!oXmlValidation.Valid) {
								return MessageBox.error(that.getI18nText(oXmlValidation.TextI18n));
							}
							var sRef = o.ruc + "-" + sInvoiceNumber;
							that.getView().setModel(sRef, "referencia");
							that.onRegistrar();
							that._getDialogM.close();
						};
						reader.onerror = function (e) {
							MessageToast.show("Error al leer documento XML");
						};
						reader.readAsBinaryString(oFileXml);
					}
				} else {
					if (n[0].pdf.name === "" && !bElectronicSupplier) {
						return MessageBox.error(that.getI18nText("msgAttachmentInvoicePdf"));
					}

					/*if (n[0].blobs.length > 1) {
						return MessageToast.show("Solo se permite adjuntar un archivo PDF");
					}
					var h = n[0].blobs.filter(e => e.type === "application/pdf");
					if (h.length === 0) {
						return MessageToast.show("Archivo PDF obligatorio!");
					} else if (h.length > 1) {
						return MessageToast.show("Solo se permite un archivo PDF");
					}*/
					var o = that.getView().getModel("Usuario").getData();
					var E = o.ruc + "-" + sInvoiceNumber;
					that.getView().setModel(E, "referencia");
					that.onRegistrar();
					that._getDialogM.close();
				}
				//that.getView().getModel("EventosModel").setProperty("/tableMode", "SingleSelectLeft");
			}, function (err) {
				console.log(err);
			});
		},
		onDialogMasivo: function () {
			var e = this;
			if (!e._getDialogM) {
				e._getDialogM = sap.ui.xmlfragment("idMasivoDialog", "com.everis.suppliers.invoiceregister.view.fragments.Masivo", e);
				e.getView().addDependent(e._getDialogM)
			}
			var t = [{
				tipodocumento: "01",
				numeroFactura: "",
				fechaFactura: "",
				total: String(e.total),
				textoCabecera: "",
				moneda: e.moneda
			}];
			var a = new JSONModel(t);
			e.getView().setModel(a, "Masivo");
			e._getDialogM.open()
		},
		flag: false,
		onPreRegistrar: function () {
			var that = this;
			var a = this.getView().byId("POHeaderTable");
			var r = a.getSelectedItems();
			if (r.length === 0) {
				return MessageToast.show("No ha seleccionado ninguno.")
			}
			this.total = 0;
			for (var o in r) {
				//Duro
				var i = r[o].getCells()[5].getText();
				this.total += parseFloat(Number(i.replace(/,/g, "")));
				this.moneda = r[o].getCells()[6].getText();
			}
			this.total = parseFloat(this.total).toFixed(2);
			var n = this._byId("chkMASIVO").getSelected();
			var l = !!this.getView().$().closest(".sapUiSizeCompact").length;
			var c = true;
			if (!n) {
				for (var o in r) {
					//Duro
					var u = r[o].getCells()[8];
					var c = this.onValidaNumeroFactura(u);
					if (!c) {
						return;
					}
				}
			}
			if (c || !n) {
				MessageBox.confirm("Desea pre-registrar?", {
					actions: ["Si", "No"],
					styleClass: l ? "sapUiSizeCompact" : "",
					onClose: function (t) {
						if (t === "Si") {
							if (n) {
								that.flag = true;
								that.onDialogMasivo();
							} else {
								for (var a in r) {
									//Duro
									if (r[a].getCells()[8].getValue() === "" && r[a].getCells()[9].getValue() === "" && r[a].getCells()[10].getValue() === "") {
										return MessageBox.error(that.getI18nText("msgcompletefields"));
									}
								}
								that.flag = false;
								that.onRegistrar();
							}
						}
					}
				});
			}
		},
		onValidaNumeroFactura: function (e) {
			var that = this;
			var t = this;
			var a = e.getValue();
			var r = a.toUpperCase().replace(/\s/g, "");
			var o = r.split("-");
			var i = o.join("");
			var n = "";
			var aCells = e.getParent().getCells();
			var l = aCells.find(oItem => oItem.data("custom") === "selectDocumentType");
			if (l === undefined) {
				n = aCells[0].getSelectedKey();
			} else {
				n = aCells.find(oItem => oItem.data("custom") === "selectDocumentType").getSelectedKey();
				//n = oSource.getParent().getCells()[6].getSelectedKey();
			}

			var u = "";
			var d = this.getView().getModel("Usuario").getData().ruc;
			//var g = this.getView().getModel("Contacto").getData().Legalenty === "EE" ? true : false;
			var g = this.getModel("ModelGlobal").getProperty("/ElectronicSupplier");
			if (o.length === 2 && o[0].length == 4) {
				if (!/[^a-zA-Z0-9]/.test(i)) {
					if (/[a-zA-Z]/.test(i) && !g) {
						e.setValue("");
						MessageBox.error(that.getI18nText("msgFormatForElectronicSupplier") + o[0]);
						return false;
					}
					if (g) {
						if (!this.onValidateFormatoNFactura(o[0])) {
							return MessageToast.show("Proveedor registrado como emisor electrónico, por favor ingrese una factura electrónica.");
						}
					}
					u = n + "-" + c.formatoReferencia(r);
					BusyIndicator.show(0);
					var sPath = that.oModel.createKey("/ReferenceSet", {
						Xblnr: u,
						Nif: d
					});
					oDataService.consult(that, "read", sPath, "", "").then(response => {
						BusyIndicator.hide();
						that.invoiceAlreadyRegistered(that, response, e, l);
					}).catch(err => {
						console.log(err);
					});
					e.setValue(c.formatoReferencia(r));
					return true;
				} else {
					MessageToast.show("No se permiten caracteres especiales");
					return false;
				}
			} else {
				var sFormat = that.getI18nText("msgFormatInvoice");
				var sStructureFormat = "";
				if (g) {
					sStructureFormat = that.getI18nText("plhStrucInvElectronic");
				} else {
					sStructureFormat = that.getI18nText("plhStrucInvNoElectronic");
				}
				MessageBox.error(sFormat + " " + sStructureFormat);
				//MessageToast.show("N° Factura: Formato esperado XXXX-XXXXXXXX");
				return false;
			}
			return true;
		},
		onRegistrar: function () {
			var that = this;
			var e = this;
			var t, a, r;
			m = that.getView().getModel("i18n").getResourceBundle();
			var o = [];
			var i = that._byId("POHeaderTable");
			var n = i.getSelectedItems();
			var sKey = this.byId("idCmbTipoPed").getSelectedKey();
			for (var l = 0; l < n.length; l++) {
				o.push(n[l].getBindingContext().getObject())
			}
			var c = {};
			c.arreglo = o;
			if (c.arreglo[0].TIPDOCREFERENCE == "01") {
				c.arreglo[0].TIPDOCREFERENCE = "RE"
			}
			var u = new JSONModel(c);
			that.getOwnerComponent().setModel(u, "POHeader");
			var d = that._byId("POHeaderTable");
			var r = d.getSelectedItems();
			var g = {};
			g.arr = r;
			that.getOwnerComponent().setModel(g, "cab");
			if (that.getOwnerComponent().getModel("POHeader")) {
				t = JSON.parse(that.getOwnerComponent().getModel("POHeader").getJSON()).arreglo;
			}
			if (that.getOwnerComponent().getModel("oDetallePO")) {
				a = JSON.parse(that.getOwnerComponent().getModel("oDetallePO").getJSON()).arreglo;
				a = that.deleteDuplicates(a);
			}
			if (that.getOwnerComponent().getModel("cab")) {
				r = that.getOwnerComponent().getModel("cab").arr;
			}
			b = e;
			if (that.getOwnerComponent().getModel("POHeader")) {
				if (that.flag) {
					that.doRegistrar2(r, t, a, 0);
				} else {
					that.doRegistrar(r, t, a, 0);
				}
			} else {
				MessageToast.show(m.getText("NoPos"));
			}
		},
		doRegistrar2: function (e, t, a, r) {
			var o = [];
			var s = this;
			var i = e[r];
			var n = t[r];
			var l = {};
			var c = this.getView().getModel("Masivo").getData();
			var u = this.getView().getModel("Usuario").getData();
			l.ConexionPIPO = "";
			var d = this._byId("chkPIPO");
			if (d.getSelected()) {
				l.ConexionPIPO = "X"
			}
			l.DOCUMENTTYPE = "RE";
			l.ClasePedido = n.ClasePedido;
			l.SUPPLIERID = u.ruc;
			l.PAYMENT_TERMS = "";
			l.PO_NUMBER = "";
			//Duro
			l.REFERENCE = c[0].tipodocumento + "-" + i.getCells()[8].getValue();
			l.TOTAL_VALUE = c[0].total;
			l.CURRENCY = n.CURRENCY;
			l.COMPANY_CODE = n.ItCompanyId;
			l.ORDER_DATE = "";
			l.TYPE = "";
			l.MESSAGE = "";
			l.COMPANY = n.COMPANY;
			l.DN_NUMBER = "";
			l.HEADER_TEXT = c[0].textoCabecera;
			l.PSTYP = n.PSTYP;
			l.DocumentTypeId = n.DocumentTypeId;
			l.DocTypeSunat = n.DocTypeSunat;
			//Duro
			var g = i.getCells()[9].getValue();
			l.DOC_DATE = g.substring(0, 4) + g.substring(5, 7) + g.substring(8, 10);
			var f = [];
			var v = [];
			for (var h in e) {
				var p = {};
				p.SUPPLIERID = u.ruc;
				p.RNG_REQUEST_DATE = c[0].fechaFactura;
				p.RNG_COMPANY_ID = t[h].ItCompanyId;
				p.PO_NUMBER = t[h].PO_NUMBER;
				p.CURRENCY = t[h].CURRENCY;
				//Duro
				p.WRBTR = e[h].getCells()[5].getText().replace(/,/g, "");
				p.DM_NUMBER = e[h].getCells()[1].getText();
				v.push(p)
			}
			l.RegHeaderToPos = v;
			l.PoLineSet = [];
			this.serviceCreateInvoiceRegSet(this, l)
		},
		serviceCreateInvoiceRegSet: function (that, t) {
			var that = this;
			var a = that.getView().getModel();
			a.create("/InvoiceRegSet", t, {
				success: function (r, o) {
					MessageToast.show(o.data.MESSAGE);
					var i = o.data;
					if (i.TYPE === "E") {
						that._addPopoverMessage("Error", m.getText("PopTitle") + i.REFERENCE, i.MESSAGE)
					} else {
						that._addPopoverMessage("Success", m.getText("PopTitle") + i.REFERENCE, i.MESSAGE);
						//Variable para SharePoint
						var sFolderNameFile = i.REFERENCE;
						var n = that.getView().getModel("referencia");
						var l = that.getView().getModel("UploadModel");
						var f = that.getView().getModel("documentService").getData();

						var aUploadAttachments = l.getData().Registro.filter(e => e.DN_NUMBER === "Masivo" && e.PO_NUMBER === "Masivo")[0];
						var p = 0;
						var R = new Date;
						R.setFullYear(t.DOC_DATE.substr(0, 4), t.DOC_DATE.substr(4, 2) - 1, t.DOC_DATE.substr(6, 2));
						var P = {
							PO_NUMBER: t.COMPANY_CODE,
							RUC: t.SUPPLIERID,
							FOLIO: t.REFERENCE,
							RAZON_SOCIAL: "",
							FECHA_DOCUMENTO: R,
							MONTO: t.TOTAL_VALUE,
							MONEDA: t.CURRENCY,
							AnexoToFile: []
						};
						var sRoute = sAmbient + "/" + sProject + "/" + P.RUC,
							fI18n = m,
							oDataDS = f,
							oParentResponse = i,
							sMessageAnexo = i.REFERENCE;
						var aUploadColletionItems = [];
						var sReference = r.REFERENCE;
						//Archivos restantes
						if (aUploadAttachments.blobs.length > 0) {
							aUploadColletionItems = aUploadColletionItems.concat(aUploadAttachments.blobs);
						}
						//Xml de la factura
						if (aUploadAttachments.xml.name !== "") {
							aUploadColletionItems.push(aUploadAttachments.xml.file);
						}
						//Pdf de la factura
						if (aUploadAttachments.pdf.name !== "") {
							aUploadColletionItems.push(aUploadAttachments.pdf.file);
						}
						that.sFullPath = sRoute;
						var sFileName = "";

						var aFilesSharePoint = [],
							oAnexoSet = P;

						that.saveFilesInRepository(that, sTypeRepository, aUploadColletionItems, aUploadAttachments, sFileName, sReference,
							aFilesSharePoint, p,
							oAnexoSet, oParentResponse, fI18n, sMessageAnexo, sFolderNameFile, oDataDS);

					}
					that.getView().getModel().refresh();
					that.clearTable();
				},
				error: function (a) {
					MessageToast.show(m.getText("Error"));
					e._addPopoverMessage("Error", m.getText("PopTitle") + t.REFERENCE, m.getText("ErrorMsg"))
				}
			})
		},
		doRegistrar: function (e, t, a, r) {
			var that = this;
			var o = this.getView().getModel();
			var i = e[r];
			var n = t[r];
			var l = {};
			var c = this;
			var u = this.getView().getModel("Usuario").getData();
			l.ConexionPIPO = "";
			var d = this._byId("chkPIPO");
			if (d.getSelected()) {
				l.ConexionPIPO = "X"
			}
			var g = c.getView().getModel("referencia");
			var sDocumentType = i.getCells().find(oItem => oItem.data("custom") === "selectDocumentType").getSelectedKey();
			var sReferenceValue = i.getCells().find(oItem => oItem.data("custom") === "inputReference").getValue();
			l.DOCUMENTTYPE = "RE";
			l.ClasePedido = n.ClasePedido;
			l.SUPPLIERID = u.ruc;
			l.PAYMENT_TERMS = "";
			l.PO_NUMBER = n.PO_NUMBER;
			//	l.REFERENCE = i.getCells()[6].getSelectedKey() + "-" + i.getCells()[7].getValue();
			l.REFERENCE = sDocumentType + "-" + sReferenceValue;
			//Duro
			l.TOTAL_VALUE = i.getCells()[5].getText().replace(/,/g, "");
			l.CURRENCY = n.CURRENCY;
			l.COMPANY_CODE = n.ItCompanyId;
			l.ORDER_DATE = "";
			l.TYPE = "";
			l.MESSAGE = "";
			l.COMPANY = n.COMPANY;
			l.DN_NUMBER = i.getCells()[1].getText();
			l.PSTYP = n.PSTYP;
			l.DocumentTypeId = n.DocumentTypeId;
			l.DocTypeSunat = n.DocTypeSunat;
			l.HEADER_TEXT = n.HEADER_TEXT;
			//Duro
			var f = i.getCells()[9].getValue();
			l.DOC_DATE = f.substring(0, 4) + f.substring(5, 7) + f.substring(8, 10);
			var v = [];
			a = undefined;
			if (a) {
				for (var h = 0; h < a.length; h++) {
					var p = a[h];
					if (p.PO_NUMBER === l.PO_NUMBER) {
						var C = {};
						C.PO_NUMBER = p.PO_NUMBER;
						C.PO_UNIT = p.PO_UNIT;
						C.ItCompanyId = p.ItCompanyId;
						C.ITEMNUMBER = p.ITEMNUMBER;
						C.MATERIALNUMBER = p.MATERIALNUMBER;
						C.ITEMDESCRIPTION = p.ITEMDESCRIPTION;
						C.QUANTITY = p.QUANTITY.replace(/,/g, "");
						C.UNITPRICE = p.UNITPRICE.replace(/,/g, "");
						C.CURRENCY = p.CURRENCY;
						C.SUBTOTAL = p.SUBTOTAL.replace(/,/g, "");
						v.push(C)
					}
				}
			}
			l.RegHeaderToPos = [];
			l.PoLineSet = [];
			if (n.DocumentType === "SERVICIOS") {
				l.PoLineSet = v
			} else {
				l.RegHeaderToPos = v
			}
			o.create("/InvoiceRegSet", l, {
				success: function (i, n) {
					MessageToast.show(n.data.MESSAGE);

					var u = n.data;
					if (u.TYPE === "E") {
						b._addPopoverMessage("Error", m.getText("PopTitle") + u.DN_NUMBER, u.MESSAGE)
					} else {
						b._addPopoverMessage("Success", m.getText("PopTitle") + u.DN_NUMBER, u.MESSAGE);
						//Variable para SharePoint
						var sFolderNameFile = u.REFERENCE;
						var d = c.getView().getModel("UploadModel");
						var f = c.getView().getModel("documentService").getData();
						var aUploadAttachments = d.getData().Registro.filter(e => e.DN_NUMBER === l.DN_NUMBER && e.PO_NUMBER === l.PO_NUMBER)[0];
						var p = 0;
						var R = new Date;
						R.setFullYear(l.DOC_DATE.substr(0, 4), l.DOC_DATE.substr(4, 2) - 1, l.DOC_DATE.substr(6, 2));
						var P = {
							PO_NUMBER: l.COMPANY_CODE,
							RUC: l.SUPPLIERID,
							FOLIO: l.REFERENCE,
							RAZON_SOCIAL: "",
							FECHA_DOCUMENTO: R,
							MONTO: l.TOTAL_VALUE,
							MONEDA: l.CURRENCY,
							AnexoToFile: []
						};
						var sRoute = sAmbient + "/" + sProject + "/" + P.RUC,
							fI18n = m,
							oDataDS = f,
							oParentResponse = u,
							sMessageAnexo = u.DN_NUMBER;
						var aUploadColletionItems = [];
						var sReference = i.REFERENCE;
						//Archivos restantes
						if (aUploadAttachments.blobs.length > 0) {
							aUploadColletionItems = aUploadColletionItems.concat(aUploadAttachments.blobs);
						}
						//Xml de la factura
						if (aUploadAttachments.xml.name !== "") {
							aUploadColletionItems.push(aUploadAttachments.xml.file);
						}
						//Pdf de la factura
						if (aUploadAttachments.pdf.name !== "") {
							aUploadColletionItems.push(aUploadAttachments.pdf.file);
						}
						that.sFullPath = sRoute;
						var sFileName = "";

						var aFilesSharePoint = [],
							oAnexoSet = P;
						that.saveFilesInRepository(that, sTypeRepository, aUploadColletionItems, aUploadAttachments, sFileName, sReference,
							aFilesSharePoint, p,
							oAnexoSet, oParentResponse, fI18n, sMessageAnexo, sFolderNameFile, oDataDS);
					}
					r++;
					that.getView().getModel().refresh();
					that.clearTable();
					if (r < t.length) {
						b.doRegistrar(e, t, a, r);
					} else {
						that.getView().getModel().refresh();
						that.clearTable();
					}

				},
				error: function (i) {
					MessageToast.show(m.getText("Error"));
					b._addPopoverMessage("Error", m.getText("PopTitle") + l.PO_NUMBER, m.getText("ErrorMsg"));
					r++;
					if (r < t.length) {
						that.doRegistrar(e, t, a, r);
					} else {
						that.getView().getModel().refresh();
						that.clearTable();
					}
				}
			})
		},

		_onPageNavButtonPress: function () {
			var e = r.getInstance();
			var t = e.getPreviousHash();
			var a = this.getQueryParameters(window.location);
			if (t !== undefined || a.navBackToLaunchpad) {
				window.history.go(-1)
			} else {
				var o = sap.ui.core.UIComponent.getRouterFor(this);
				o.navTo("default", true)
			}
		},
		getQueryParameters: function (e) {
			var t = {};
			var a = e.search.substring(1).split("&");
			for (var r = 0; r < a.length; r++) {
				var o = a[r].split("=");
				t[o[0]] = decodeURIComponent(o[1])
			}
			return t
		},
		onDisplayFilter: function (e) {
			var a = "Dialog1";
			this.mDialogs = this.mDialogs || {};
			var r = this.mDialogs[a];
			var o;
			var s;
			if (!r) {
				this.getOwnerComponent().runAsOwner(function () {
					s = sap.ui.xmlview({
						viewName: "com.everis.suppliers.invoiceregister.view." + a
					});
					this.getView().addDependent(s);
					s.getController().setRouter(this.oRouter);
					r = s.getContent()[0];
					this.mDialogs[a] = r
				}.bind(this))
			}
			return new Promise(function (e) {
				r.attachEventOnce("afterOpen", null, e);
				r.open();
				if (s) {
					r.attachAfterOpen(function () {
						r.rerender()
					})
				} else {
					s = r.getParent()
				}
				var t = this.getView().getModel();
				if (t) {
					s.setModel(t)
				}
				if (o) {
					var a = s.getController().getBindingParameters();
					s.bindObject({
						path: o,
						parameters: a
					})
				}
			}.bind(this)).catch(function (e) {
				if (e !== undefined) {
					MessageBox.error(e.message)
				}
			})
		},
		_onButtonPress1: function (e) {
			var a = "Dialog4";
			this.mDialogs = this.mDialogs || {};
			var r = this.mDialogs[a];
			var o = e.getSource();
			var s = o.getBindingContext();
			var i = s ? s.getPath() : null;
			var n;
			if (!r) {
				this.getOwnerComponent().runAsOwner(function () {
					n = sap.ui.xmlview({
						viewName: "com.everis.suppliers.invoiceregister.view." + a
					});
					this.getView().addDependent(n);
					n.getController().setRouter(this.oRouter);
					r = n.getContent()[0];
					this.mDialogs[a] = r
				}.bind(this))
			}
			return new Promise(function (e) {
				r.attachEventOnce("afterOpen", null, e);
				r.open();
				if (n) {
					r.attachAfterOpen(function () {
						r.rerender()
					})
				} else {
					n = r.getParent()
				}
				var t = this.getView().getModel();
				if (t) {
					n.setModel(t)
				}
				if (i) {
					var a = n.getController().getBindingParameters();
					n.bindObject({
						path: i,
						parameters: a
					})
				}
			}.bind(this)).catch(function (e) {
				if (e !== undefined) {
					MessageBox.error(e.message)
				}
			})
		},
		_onLinkPress: function (e) {
			var t = e.getSource().getBindingContext();
			var a = t.getObject();
			var r = new JSONModel({
				TipDoc: a.TIPDOCREFERENCE,
				DocTypeSunat: a.DocTypeSunat
			});
			sap.ui.getCore().setModel(r, "TipDoc");
			if (a.DocumentType === "SERVICIOS") {
				this.oRouter.navTo("PoLineContext", {
					context: t.getPath().substr(1)
				})
			} else {
				this.oRouter.navTo("DetalleOcContext", {
					context: t.getPath().substr(1)
				})
			}
		},
		onDialogOk: function (e) {
			var t = e.getSource().getParent();
			var a = this._byId("idRdBtnOrderedT");
			var r = a.getSelectedButton().getText();
			var o = this.getView().getModel("OrderedType").getData();
			var s = [];
			var l = o.find(function (e) {
				return e.Batxt === r
			}).Bsart;
			this.byId("idCmbTipoPed").setSelectedKey(l);
			var c = l;
			s.push(new i({
				filters: [new i("ClasePedido", "EQ", c)]
			}));
			var u = new Date;
			var d = "";
			d = u.toLocaleString("en-GB", {
				timeZone: "UTC"
			});
			d = d.substring(6, 10) + d.substring(3, 5) + d.substring(0, 2);
			u.setDate(u.getDate() - 30);
			var g = u.toLocaleString("en-GB", {
				timeZone: "UTC"
			});
			var f = g.substring(6, 10) + g.substring(3, 5) + g.substring(0, 2);
			s.push(new i({
				filters: [new i("ItRequestDate", "BT", f, d)]
			}));
			s.push(new i({
				path: "ItTaxIdNumber",
				operator: n.EQ,
				value1: this.oUser_
			}));
			var v = this.getView().byId("POHeaderTable");
			var h = v.getBinding("items");
			h.filter(new i({
				filters: s,
				and: true
			}));
			t.close();
		},

		_formatDate: function (e) {
			var t, a, r;
			if (e.substr(1, 1) === "/") {
				t = "0" + e.substr(0, 1);
				if (e.substr(3, 1) === "/") {
					a = "0" + e.substr(2, 1);
					r = e.substr(4, 4);
				} else {
					a = e.substr(2, 2);
					r = e.substr(5, 4);
				}
			} else {
				t = e.substr(0, 2);
				if (e.substr(4, 1) === "/") {
					a = "0" + e.substr(3, 1);
					r = e.substr(5, 4);
				} else {
					a = e.substr(3, 2);
					r = e.substr(6, 4);
				}
			}
			var o = t + "/" + a + "/" + r;
			return o;
		},
		onUpdateFinished: function (e) {
			var t = e.getSource().getItems().length;
			var a = e.getSource().getHeaderToolbar();
			a.getContent()[0].setText("Pedidos (" + t + ")");
		},
		formatNumber: function (e) {
			jQuery.sap.require("sap.ui.core.format.NumberFormat");
			var t = new sap.ui.core.Locale("en-US");
			var a = {
				minIntegerDigits: 3,
				minFractionDigits: 2,
				maxFractionDigits: 2,
				groupingSeparator: ","
			};
			var r = sap.ui.core.format.NumberFormat.getFloatInstance(a, t);
			return r.format(e).replace(/^\b0+\B/, "")
		},
		fechaFiltro: function (e, t) {
			var a = this;
			var r = new Date;
			var o;
			var s = this._byId(t);
			var i = s.setSelectedKey(e);
			var n = {
				startDate: "",
				endDate: ""
			};
			switch (e) {
			case "0":
				r.setDate(r.getDate() - 30);
				var l = new Date(r);
				var c = l.toLocaleString("en-GB", {
					timeZone: "UTC"
				});
				var u = c.substring(6, 10);
				var d = c.substring(3, 5);
				var g = c.substring(0, 2);
				o = u + d + g;
				n.startDate = o;
				return n;
			case "1":
				r.setDate(r.getDate() - 15);
				var f = new Date(r);
				var v = f.toLocaleString("en-GB", {
					timeZone: "UTC"
				});
				var h = v.substring(6, 10);
				var p = v.substring(3, 5);
				var E = v.substring(0, 2);
				o = h + p + E;
				n.startDate = o;
				return n;
			case "98":
				r.setFullYear(2017, 7, 5);
				var m = new Date(r);
				var b = m.toLocaleString("en-GB", {
					timeZone: "UTC"
				});
				var C = b.substring(6, 10);
				var M = b.substring(3, 5);
				var R = b.substring(0, 2);
				o = C + M + R;
				n.startDate = o;
				return n;
			default:
				var P = i.getSelectedItem().getText().split(" - ");
				var I = P[0].substr(6, 4) + P[0].substr(3, 2) + P[0].substr(0, 2);
				var D = P[1].substr(6, 4) + P[1].substr(3, 2) + P[1].substr(0, 2);
				n.startDate = I;
				n.endDate = D;
				return n
			}
		},
		sendData: function (e) {
			var t = [];
			var that = this;
			var r = this._byId("smartFilterBar")._retrieveCurrentSelectionSet();
			var o = this._byId("chkMASIVO");
			o.setSelected(false);
			this.getView().getModel("EventosModel").setProperty("/tableMode", "SingleSelectLeft");
			that.flag = false;
			var s = this._byId("idCmbFecha").getSelectedKey();
			var l = this._byId("idCmbTipoPed").getSelectedKey();
			var c = r ? r : [];
			var u = "";
			for (var d = 0; d < c.length; d++) {
				var g = c[d].getBinding("value");
				if (g) {
					var f = g.getModel().getData()[g.getPath().substr(1).split("/")[0]];
					var v = [];
					jQuery.each(f.ranges, function () {
						if (!this.exclude) {
							v.push(new i(this.keyField, this.operation, this.value1));
						} else {
							v.push(new i(this.keyField, "NE", this.value1));
						}
					});
					if (v.length) {
						t.push(new i({
							filters: v
						}))
					}
				} else {}
			}
			var h = this.getView().getModel("Contacto").getData();
			var p = this.getView().byId("mbxSociedad");
			var sCode = this.getView().byId("idCmbDocumentType").getSelectedKey();
			t.push(new i({
				path: "ItTaxIdNumber",
				operator: n.EQ,
				value1: h.Ruc
			}));
			t.push(new i({
				path: "ItCompanyId",
				operator: n.EQ,
				value1: p.getSelectedKey()
			}));
			t.push(new i({
				path: "DocTypeSunat",
				operator: "EQ",
				value1: sCode
			}));
			var E = this.fechaFiltro(s, "idCmbFecha");
			if (s === "98" || s === "0" || s === "1") {
				t.push(new i({
					filters: [new i("FECHA_FACTURA", "GE", E.startDate)]
				}))
			} else {
				t.push(new i({
					filters: [new i("FECHA_FACTURA", "BT", E.startDate, E.endDate)]
				}))
			}
			var m = l;
			t.push(new i({
				filters: [new i("ClasePedido", "EQ", m)]
			}));
			var b = this.getView().byId("POHeaderTable");
			var C = b.getBinding("items");
			C.filter(new i({
				filters: t,
				and: true
			}));
			that.getDocumentTypeForTable(that, sCode);
			if (sCode === "AN") {
				that.getView().getModel("ModelGlobal").setProperty("/Anticipo", true);
			} else {
				that.getView().getModel("ModelGlobal").setProperty("/Anticipo", false);
			}
		},
		handleSortButtonPressed: function () {
			var e = this.getView();
			this.createViewSettingsDialog = sap.ui.xmlfragment(e.getId(),
				"com.everis.suppliers.invoiceregister.view.fragments.SortDialog", this);
			this.createViewSettingsDialog.open()
		},
		handleSortDialogConfirm: function (e) {
			var t = this.byId("POHeaderTable"),
				a = e.getParameters(),
				r = t.getBinding("items"),
				o, s, i = [];
			o = a.sortItem.getKey();
			s = a.sortDescending;
			i.push(new u(o, s));
			r.sort(i)
		},
		_onSelectionChange: function (e) {
			var t = this.getView();
			var a = e.getParameters().selectedItem;
			var r = a.getKey();
			if (r === "99") {
				if (!this.pressDialog) {
					this.pressDialog = sap.ui.xmlfragment(t.getId(), "com.everis.suppliers.invoiceregister.view.fragments.PressDialog", this);
					this.getView().addDependent(this.pressDialog)
				}
				this.pressDialog.open()
			} else {
				this.oCboIndex = r
			}
		},
		_onDialogBtnPress: function (e) {
			var t = this.byId("idCmbFecha");
			var a = t.getItems().length;
			this.oCboIndex = a;
			var r = this.byId("DRS1").getValue();
			var o = true;
			jQuery.each(t.getItems(), function () {
				if (this.getText() === r) {
					o = false;
					MessageToast.show("El rango de fechas seleccionado ya se encuentra en la lista");
					return
				}
			});
			if (o && r) {
				t.insertItem(new sap.ui.core.Item({
					text: r,
					key: a
				}), a);
				t.setSelectedKey(a)
			} else {
				t.setSelectedKey(a - 1)
			}
			this.pressDialog.close()
		},
		_onDialogClose: function () {
			if (this.pressDialog) {
				this._byId("idCmbFecha").setSelectedKey(this.oCboIndex);
				this.pressDialog.close()
			}
		},
		onExport: function (e) {
			var t, a;
			var r = this.getView().byId("POHeaderTable");
			t = this.createColumnConfig();
			var o = r.getItems();
			var i = [];
			jQuery.each(o, function () {
				var e = {};
				var t = this.getCells();
				var sDocumentType = i.getCells().find(oItem => oItem.data("custom") === "selectDocumentType").getSelectedKey();
				var sReferenceValue = i.getCells().find(oItem => oItem.data("custom") === "inputReference").getValue();
				//Duro
				e["PO_NUMBER"] = t[4].getText();
				e["COMPANY"] = t[12].getText();
				e["DOCUMENTTYPE"] = t[0].getText();
				e["TOTAL_VALUE"] = t[5].getText();
				e["CURRENCY"] = t[6].getText();
				e["REFERENCE"] = sDocumentType + "-" + sReferenceValue;
				e["DOC_DATE"] = t[9].getValue();
				e["HEADER_TXT"] = t[10].getValue();
				i.push(e);
			});
			a = {
				workbook: {
					columns: t
				},
				dataSource: i,
				worker: false,
				fileName: "preRegistroFactura"
			};
			new l(a).build().then(function () {
				MessageToast.show("Spreadsheet export has finished");
			});
		},
		refresh: function () {
			var e = this;
			var t = e.getView().getModel();
			t.read("/DirssSet", {
				success: function (t) {
					var a = new JSONModel(t.results);
					e.getView().setModel(a, "OrderedType");
					e.getView().getModel("OrderedType").updateBindings(true)
				},
				error: function (e) {}
			})
		},
		onBeforeUploadStarts: function (e) {},
		onValidateFormatoNFactura: function (e) {
			e = e.replace(/[-\s]/g, "");
			var t = /^[0-9]+$/;
			var a = /^[A-Z]+$/i;
			var r = /^[a-zA-Z0-9]+$/;
			if (t.test(e) || a.test(e)) {
				return false;
			} else {
				return r.test(e);
			}
		},
		onValidateNumXml: function (e) {
			var t = e[0].filter(e => e.type === "text/xml");
			return t.length > 1;
		},
		onPressUploadAttachments: function (oEvent) {
			var oModelUploadModel = this.getView().getModel("UploadModel");
			var aDataUploadModel = oModelUploadModel.getData().Registro;
			var bCheckMasive = this._byId("chkMASIVO").getSelected();
			if (!bCheckMasive) {
				this.oRowSelected = oEvent.getSource().getBindingContext().getObject();
				this.oRowSelectedForUpdate = oEvent.getSource().getParent().getCells();
				var oItemSelected = oEvent.getSource().getBindingContext().getObject();
				this.getView().setModel(oItemSelected, "Line");
			} else {
				this.oRowSelected = oEvent.getSource().getBindingContext("Masivo").getObject();
			}
			var sDnNumber = bCheckMasive ? "Masivo" : oItemSelected.DN_NUMBER;
			var sPoNumber = bCheckMasive ? "Masivo" : oItemSelected.PO_NUMBER;
			var oRegister = {
				DN_NUMBER: sDnNumber,
				PO_NUMBER: sPoNumber,
				uploadCollection: [],
				blobs: [],
				xml: {
					name: "",
					file: {}
				},
				pdf: {
					name: "",
					file: {}
				}
			};
			if (aDataUploadModel.length === 0) {
				aDataUploadModel.push(oRegister);
			} else {
				var g = aDataUploadModel.filter(e => e.DN_NUMBER === sDnNumber && e.PO_NUMBER === sPoNumber);
				if (g.length === 0) {
					aDataUploadModel.unshift(oRegister);
				}
			}
			var oDataFilter = aDataUploadModel.filter(e => e.DN_NUMBER === sDnNumber && e.PO_NUMBER === sPoNumber);
			var oModel = new JSONModel(oDataFilter[0]);

			this.setFragment(this, "dialogUploadAttachments", "idUploadAttachments", "UploadDialog", sRouteDialog);
			this["dialogUploadAttachments"].setModel(oModel, "UploadAttachments");
			this["dialogUploadAttachments"].open();
		},
		_onChangeAddFile: function (oEvent) {
			var oParameters = oEvent.getParameters("files");
			var oFile = oParameters.files[0];
			var oDataUploadAttachments = this["dialogUploadAttachments"].getModel("UploadAttachments").getData();
			var oFind = oDataUploadAttachments.blobs.find(e => e.name === oFile.name);
			if (oFind === undefined) {
				oDataUploadAttachments.blobs.push(oFile);
			} else {
				MessageBox.error(this.getI18nText("msgSameFilename"));
			}

			this["dialogUploadAttachments"].getModel("UploadAttachments").refresh();
		},
		onPressFileRemove: function (oEvent) {
			var oSource = oEvent.getSource();
			var oBContext = oSource.getBindingContext("UploadAttachments");
			var sPath = oBContext.getPath().split("/")[2];
			var aFile = this["dialogUploadAttachments"].getModel("UploadAttachments").getData();
			aFile.blobs.splice(sPath, 1);
			this["dialogUploadAttachments"].getModel("UploadAttachments").updateBindings();
		},
		onSaveFile: function (oEvent) {
			var that = this;
			var oSource = oEvent.getSource();
			var sCustom = oSource.data("custom");
			var oParameters = oEvent.getParameters("files");
			var oFile = oParameters.files[0];
			var reader = new FileReader;
			var oDataUploadAttachments = this["dialogUploadAttachments"].getModel("UploadAttachments").getData();
			switch (sCustom) {
			case 'XML':
				reader.onload = function (oEvent) {
					var oDataValidation = Object.assign({}, that.oRowSelected);
					that.oRowSelected = Object.assign({}, that.oRowSelected);
					var bMasive = false;
					if (!oDataValidation.hasOwnProperty("tipodocumento") && !oDataValidation.hasOwnProperty("fechaFactura") && !oDataValidation.hasOwnProperty(
							"moneda") && !oDataValidation.hasOwnProperty("numeroFactura")) {
						oDataValidation.tipodocumento = oDataValidation.TIPDOCREFERENCE;
						oDataValidation.fechaFactura = oDataValidation.FechaFacturaP;
						oDataValidation.moneda = oDataValidation.CURRENCY;
						oDataValidation.numeroFactura = oDataValidation.REFERENCE;
					} else {
						bMasive = true;
					}

					var oXmlValidation = that.xmlValidation(that, oEvent, oDataValidation, bMasive, aTag, that.oRowSelected);
					var oItemTableSelected = that.byId("POHeaderTable").getSelectedItem();
					if (oXmlValidation.Error) {
						if (oItemTableSelected !== null && !bMasive) {
							oItemTableSelected.setSelected(false);
						}
						oDataUploadAttachments.xml.name = {
							name: ""
						};
						that["dialogUploadAttachments"].getModel("UploadAttachments").refresh();
						return MessageBox.error(oXmlValidation.TextError);
					} else if (!oXmlValidation.Valid) {
						if (oItemTableSelected !== null && !bMasive) {
							oItemTableSelected.setSelected(false);
						}
						oDataUploadAttachments.xml = {
							name: ""
						};
						that["dialogUploadAttachments"].getModel("UploadAttachments");
						return MessageBox.error(that.getI18nText(oXmlValidation.TextI18n));
					}
					if (!bMasive) {
						//Duro
						that.oRowSelectedForUpdate[8].setValue(that.oRowSelected.REFERENCE);
						that.oRowSelectedForUpdate[9].setValue(that.oRowSelected.FechaFacturaP);
					} else {
						that.getModel("Masivo").setProperty("/0/numeroFactura", that.oRowSelected.REFERENCE);
						that.getModel("Masivo").setProperty("/0/fechaFactura", that.oRowSelected.FechaFacturaP);
					}

					//oDataUploadAttachments.xml = oFile;
					oDataUploadAttachments.xml.name = oFile.name;
					oDataUploadAttachments.xml.file = oFile;
				};
				reader.onerror = function (oEvent) {
					MessageToast.show("Error al leer documento XML");
				};
				reader.readAsBinaryString(oFile);
				break;
			case 'PDF':
				//oDataUploadAttachments.pdf = oFile;
				oDataUploadAttachments.pdf.name = oFile.name;
				oDataUploadAttachments.pdf.file = oFile;
				break;
			default:
			}
		},
		onClose: function (oEvent) {
			var oSource = oEvent.getSource();
			var oParent = oSource.getParent();
			oParent.close();
		},
		onChangeUpload: function (e) {},
		xmlToJson: function (e) {
			var t = {};
			if (e.nodeType === 1) {
				if (e.attributes.length > 0) {
					t["@attributes"] = {};
					for (var a = 0; a < e.attributes.length; a++) {
						var r = e.attributes.item(a);
						t["@attributes"][r.nodeName] = r.nodeValue
					}
				}
			} else if (e.nodeType === 3) {
				t = e.nodeValue
			}
			if (e.hasChildNodes()) {
				for (var o = 0; o < e.childNodes.length; o++) {
					var s = e.childNodes.item(o);
					var i = s.nodeName;
					if (typeof t[i] === "undefined") {
						t[i] = this.xmlToJson(s)
					} else {
						if (typeof t[i].push === "undefined") {
							var n = t[i];
							t[i] = [];
							t[i].push(n)
						}
						t[i].push(this.xmlToJson(s))
					}
				}
			}
			return t
		},
		readUserApiInfo: function () {
			return new Promise(function (e, t) {
				var a = new JSONModel("/services/userapi/attributes");
				a.attachRequestCompleted(function () {
					e(a)
				});
				a.attachRequestFailed(function () {
					t("Error")
				})
			})
		},
		onExit: function () {
			this._BusyDialog.close()
		},
		onSelectChange: function (e) {
			var t = e.getSource().getBindingContext().getObject();
			var a = e.getSource().getSelectedKey();
			var r = this._byId("POHeaderTable");
			//Duro
			var o = r.getItems().filter(e => e.getCells()[1].getText() === t.DN_NUMBER && e.getCells()[4].getText() === t.DM_NUMBER);
			if (o.length > 0) {
				/*if (a === "01") {
					o[0].getCells()[5].setText(t.TOTAL_VALUE_IGV)
				} else {
					o[0].getCells()[5].setText(t.TOTAL_VALUE_NO_IGV)
				}*/
				o[0].getCells()[5].setText(t.TOTAL_VALUE_IGV);
			}
		},
		onSelectMassiveChange: function (e) {
			var t = this.getView().getModel("Masivo").getData();
			var a = this.getView().byId("POHeaderTable");
			var r = a.getSelectedItems();
			if (t.length > 0) {
				t[0].total = 0;
				for (var o in r) {
					/*if (t[0].tipodocumento === "01") {
						//Duro
						var s = r[o].getCells()[14].getText();
						t[0].total += parseFloat(Number(s.replace(/,/g, "")))
					} else {
						//Duro
						var s = r[o].getCells()[13].getText();
						t[0].total += parseFloat(Number(s.replace(/,/g, "")))
					}*/
					var s = r[o].getCells()[14].getText();
					t[0].total += parseFloat(Number(s.replace(/,/g, "")));
				}
				t[0].total = String(parseFloat(t[0].total).toFixed(2))
			}
		},
		readUserIasInfo: function () {
			return new Promise(function (resolve, reject) {
				var userModel = new JSONModel({});
				var sMail = sap.ushell.Container.getService("UserInfo").getUser().getEmail();
				if (sMail === "DEFAULT_USER" || sMail === undefined) sMail = "proveedor_kallpa1@yopmail.com";
				//var sMail = "juan_perez@gmail.com";
				var sPath = "/iasscim/Users?filter=emails eq '" + sMail + "'";
				userModel.loadData(sPath, null, true, 'GET', null, null, {
					'Content-Type': 'application/scim+json'
				}).then(() => {

					var oDataTemp = userModel.getData();
					var oData = {};
					var aAttributes = oDataTemp.Resources[0]["urn:sap:cloud:scim:schemas:extension:custom:2.0:User"];
					oData = {
						company: "",
						email: oDataTemp.Resources[0].emails[0].value,
						emails: oDataTemp.Resources[0].emails[0].value,
						firstName: oDataTemp.Resources[0].name.givenName,
						groups: oDataTemp.Resources[0].groups,
						lastName: oDataTemp.Resources[0].name.familyName,
						loginName: oDataTemp.Resources[0].userName,
						name: oDataTemp.Resources[0].userName,
						ruc: ""
					};
					if (aAttributes !== undefined) {
						oData.ruc = oDataTemp.Resources[0]["urn:sap:cloud:scim:schemas:extension:custom:2.0:User"].attributes[0].value;
					}
					var oUserModel = new JSONModel(oData);
					resolve(oUserModel);

				}).catch(err => {
					reject(err);
				});
			});
		}
	})
}, true);