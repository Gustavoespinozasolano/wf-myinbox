sap.ui.define([
	"com/everis/suppliers/quotationupdate/test/unit/controller/Home.controller"
], function () {
	"use strict";
});