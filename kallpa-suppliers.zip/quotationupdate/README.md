## Requisitos ABAP
- El usuario de conexión hacia SAP ERP debe tener la configuración de decimales: '1,234,567.89'. (En Sistema > Valores prefijados > Datos de Usuario)