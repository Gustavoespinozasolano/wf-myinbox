sap.ui.define([
	"com/everis/suppliers/accountstatus/test/unit/controller/Principal.controller"
], function () {
	"use strict";
});