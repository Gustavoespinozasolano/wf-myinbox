sap.ui.define([
	"com/everis/suppliers/trackingApprove/test/unit/controller/Home.controller"
], function () {
	"use strict";
});