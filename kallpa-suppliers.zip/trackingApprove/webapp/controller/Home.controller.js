sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessagePopover',
	'sap/m/MessagePopoverItem',
	"sap/ui/model/json/JSONModel",
	'sap/m/MessageBox',
	'sap/m/Dialog',
	'sap/m/Label',
	'sap/m/Text',
	'sap/m/TextArea',
	'sap/m/Button',
	'sap/m/MessageToast'
], function (Controller, MessagePopover, MessagePopoverItem, JSONModel, MessageBox, Dialog, Label, Text, TextArea, Button, MessageToast) {
	"use strict";
	var oThat,
		oGeneralData;
	return Controller.extend("com.everis.suppliers.trackingApprove.controller.Home", {
		onInit: function () {
			oThat = this;
			oGeneralData = this .getOwnerComponent().getModel("GeneralData").getData();
			oThat.onGetTestData();
			oThat.onState(true, "general");
			oThat.onCreatedList();
		},
		
		onGetTestData: function () {
			var jDatos = sap.ui.require.toUrl("com/everis/suppliers/trackingApprove/model/dataGeneral.json");
			var oModel = new JSONModel(jDatos);
			oThat.getView().setModel(oModel, "listGroup");
		},
		
		onState: function (bState, modelo) {
			var oModel = new JSONModel({
				"state": bState
			});
			oThat.getView().setModel(oModel, modelo);
		},
		
		onCreatedList: function () {
			var master = oThat.getView().byId("idLista");

			master.destroyItems();

			var oData = [{
				"fechaIni": "20200616",
				"fechaFin": "20200622",
				"title": "Juan Perez",
				"number": "F0001",
				"numberState": "None",
				"type": "Active",
				"selected": true,
				"showMarkers": false,
				"text": "Pendiente",
				"color": "Success"
			}
			// , {
			// 	"fechaIni": "20200617",
			// 	"fechaFin": "20200623",
			// 	"title": "Juan Perez",
			// 	"number": "BP0002",
			// 	"numberState": "None",
			// 	"type": "Active",
			// 	"selected": false,
			// 	"showMarkers": false,
			// 	"text": "Aprobado",
			// 	"color": "Success"
			// }
			// , {
			// 	"fechaIni": "20200618",
			// 	"fechaFin": "20200624",
			// 	"title": "Christian Pelaez",
			// 	"number": "BP0003",
			// 	"numberState": "None",
			// 	"type": "Active",
			// 	"selected": false,
			// 	"showMarkers": false,
			// 	"text": "Rechazado",
			// 	"color": "Error"
			// }
			];

			$.each(oData, function (k, v) {
				var fechaIni = v.fechaIni,
					fechaFin = v.fechaFin;

				var item = new sap.m.ObjectListItem({
					title: v.title,
					number: v.number,
					// numberUnit: v.PRODUCTIONUNIT,
					numberState: v.numberState,
					type: v.type,
					selected: v.selected,
					showMarkers: v.showMarkers
				});

				var attribute = new sap.m.ObjectAttribute({
					text: "",
					active: false,
					visible: true
				});

				item.addAttribute(attribute);

				var attribute3 = new sap.m.ObjectAttribute({
					text: "F. Solicitud: " + fechaIni.substr(6, 2) + "/" + fechaIni.substr(4, 2) + "/" + fechaIni.substr(0, 4),
					active: false,
					visible: true
				});

				item.addAttribute(attribute3);

				var attribute2 = new sap.m.ObjectAttribute({
					text: "F. Aprobacion.: " + fechaFin.substr(6, 2) + "/" + fechaFin.substr(4, 2) + "/" + fechaFin.substr(0, 4),
					active: false,
					visible: true
				});

				item.addAttribute(attribute2);

				var status1 = new sap.m.ObjectStatus({
					text: v.text,
					visible: true
				});

				item.setFirstStatus(status1);

				master.addItem(item);
			});
			sap.ui.core.BusyIndicator.hide();
		},
		
		onCancelRequest: function () {
			MessageBox.confirm(oThat.getView().getModel("i18n").getResourceBundle().getText("reCancelRequest"), {
				title: "Confirmacion",
				actions: ["Si", "No"],
				onClose: function (sActionClicked) {

					if (sActionClicked === 'Si') {
						var dialog = new Dialog({
							title: 'Comentario',
							type: 'Message',
							//actions: ["Aceptar", "Cancelar"],
							content: [
								new Label({
									text: oThat.getView().getModel("i18n").getResourceBundle().getText("reCancelMotivo"),
									labelFor: 'textarea'
								}),
								new TextArea('textarea', {
									liveChange: function (oEvent) {
										var MotivoNotificacion = oEvent.getParameter('value');
										var parent = oEvent.getSource().getParent();

										parent.getBeginButton().setEnabled(MotivoNotificacion.length > 0);
									},
									width: '100%',
									placeholder: 'Comentario...',
									rows: 5,
									cols: 20,
									maxLength: 40
										//value: v1.COMMENTS
								})
							],
							beginButton: new Button({
								text: 'Aceptar',
								enabled: false,
								press: function () {
									dialog.close();
									sap.ui.core.BusyIndicator.hide();
								}
							}),
							endButton: new Button({
								text: 'Cancelar',
								press: function () {
									dialog.close();
								}
							}),
							afterClose: function () {
								dialog.destroy();
							}
						});
						dialog.open();
					}
				}
			});
		},
		
		onRequestBP: function () {
			MessageBox.confirm(
				oThat.getView().getModel("i18n").getResourceBundle().getText("confirmRequest"), {
					styleClass: "sapUiSizeCompact",
					actions: [MessageBox.Action.YES, MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === "YES") {
							MessageToast.show(oThat.getView().getModel("i18n").getResourceBundle().getText("sSuccessMessage"));
							sap.ui.core.BusyIndicator.hide();
						}
					}
				}
			);
		}
	});
});