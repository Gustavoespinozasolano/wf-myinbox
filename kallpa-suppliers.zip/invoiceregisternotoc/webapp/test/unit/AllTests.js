sap.ui.define([
	"com/everis/suppliers/invoiceregisternotoc/test/unit/controller/Home.controller"
], function () {
	"use strict";
});