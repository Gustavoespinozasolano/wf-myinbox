sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessagePopover',
	'sap/m/MessagePopoverItem',
	"sap/ui/model/json/JSONModel",
	'sap/m/MessageBox',
	"sap/ui/core/BusyIndicator",
	'../service/SharePoint',
	'sap/ui/model/Filter',
	'../service/Service',
	"com/everis/suppliers/invoiceregisternotoc/model/formatter",
	'../service/Message',
	'../service/Workflow',
	'sap/m/MessageToast',
	'sap/m/Dialog',
	'sap/m/Label',
	'sap/m/Text',
	'sap/m/TextArea',
	'sap/m/Button'
], function (Controller, MessagePopover, MessagePopoverItem, JSONModel, MessageBox, BusyIndicator, SharePoint, Filter, Service, formatter,
	Message, Workflow, MessageToast, Dialog, Label, Text, TextArea, Button) {
	"use strict";
	var oThat,
		fragmentsPath = "com.everis.suppliers.invoiceregisternotoc.view",
		sEstado = "I",
		oModelGeneral,
		sCreatedByUser = "",
		sCreatedByRuc = "",
		MotivoNotificacion = "",
		oListMasterGeneral = [],
		flagValidator = true,
		sUri = "",
		sAmbient = "",
		sProject = "",
		idApp = "",
		oDocumentClassConst1 = "",
		oDocumentClassConst2 = "",
		aTag = [];
	return Controller.extend("com.everis.suppliers.invoiceregisternotoc.controller.Home", {
		formatter: formatter,
		onInit: function () {
			oThat = this;
			sEstado = "I";
			aTag = [];
			oModelGeneral = oThat.getOwnerComponent().getModel("SUPPLIERS_SRV");
			oThat.onIniciatorEnabledVisible();
			// sAmbient/app/ruc/referencia
			oThat.onIniciatorModels();
			//expira cada 12 horas
			oThat.uuid = SharePoint.getUUIDV4().toUpperCase().replace(/-/gi, '');
			oThat.onGetData();
			//Crea carpetas 
			/*	BusyIndicator.show(0);
				SharePoint.getToken(this).then(resolve => {
					oThat.bearer = resolve.access_token;
					BusyIndicator.hide();
				}).catch(err => {
					console.log(err);
				});*/
			//Se obtiene token
			BusyIndicator.show(0);
			Service.consult(oModelGeneral, "/SPTokenSet('INVOICE')", "", "").then(response => {
				BusyIndicator.hide();
				oThat.bearer = response.Token;
				if (response.Token.length === 0) {
					MessageBox.error(formatter.onGetI18nText(oThat, "msgNotToken"));
				}
			}).catch(err => {
				MessageBox.error(formatter.onGetI18nText(oThat, "msgNotToken"));
			});
			// Obtener el usuario del IAS.
			oThat.readUserIasInfo().then(function (data) {
				sCreatedByUser = data.Resources[0].userName;
				var aAttributes = data.Resources[0]["urn:sap:cloud:scim:schemas:extension:custom:2.0:User"];
				if (aAttributes !== undefined) {
					sCreatedByRuc = aAttributes.attributes[0].value;
				}
				oThat.onCreatedList();
			});

			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getRoute("RouteHome").attachMatched(this._onRouteMatched, this);

		},

		_onRouteMatched: function () {
			var sBusinessKey;
			var startupParams = this.getOwnerComponent().getComponentData().startupParameters; // get Startup params from Owner Component
			if ((startupParams.businessKey && startupParams.businessKey[0])) {
				if (startupParams.businessKey !== undefined) {
					sBusinessKey = startupParams.businessKey;
				} else {
					sBusinessKey = startupParams.businessKey[0];
				}
				oThat.onGetServiceRequestInvoice(sBusinessKey);
			}
		},
		onAfterRendering: function () {
			try {
				var sIdSplit = oThat.createId("idsplit");
				var oSplit = document.getElementById(sIdSplit);
				var oChild = oSplit.firstElementChild;
				var startupParameters = $.getComponentDataMyInbox === undefined ? undefined : $.getComponentDataMyInbox.startupParameters;
				//valida si entra por el workflow
				oThat.myInbox = false;
				if (startupParameters !== undefined && startupParameters.hasOwnProperty("taskModel")) {
					oThat.myInbox = true;
					oChild.style.display = "none";
				} else {
					oChild.style.display = "block";
				}
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		onIniciatorModels: function () {
			var oModel = new JSONModel([]);
			var oModelFile = new JSONModel([]);
			var oModelFolder = new JSONModel([{
				Id: "XML",
				Name: "XML"
			}, {
				Id: "AR1",
				Name: "AR1"
			}, {
				Id: "AR2",
				Name: "AR2"
			}, {
				Id: "AR3",
				Name: "AR3"
			}]);
			var oModelNameFile = new JSONModel({
				XML: "",
				AR1: "",
				AR2: "",
				AR3: ""
			});
			var oModelSearch = new JSONModel({
				value: ""
			});
			//Modelo donde se guardaran rutas de archivos individuales
			oThat.getView().setModel(oModelFile, "file");
			//Modelo donde se guardaran rutas de archivos individuales
			oThat.getView().setModel(oModelFolder, "folder");
			//Modelo que guarda nombre de los archivos que vas adjuntando
			oThat.getView().setModel(oModelNameFile, "UploadFile");
			//Modelo para hacer busqueda en la lista del master
			oThat.getView().setModel(oModelSearch, "search");
			//Modelo donde se guardara la informacion del historial o time line
			oThat.getView().setModel(oModel, "listTimeLine");
		},

		// Inicializador de modelos de las tablas de los tabs.
		onIniciatorEnabledVisible: function () {
			oThat.onState(true, "general");
			oThat.onState(false, "visible");
			oThat.onState(false, "timeLine");
			oThat.onState(false, "voucher");
			oThat.onState(0, "count");
		},

		onState: function (bState, modelo) {
			var oModel = new JSONModel({
				"state": bState
			});
			if(oThat.getView().getModel(modelo)){
				oThat.getView().getModel(modelo).setProperty("/state", bState);
			}else{
				oThat.getView().setModel(oModel, modelo);
			}
			// oThat.getView().setModel(oModel, modelo);
			oThat.getView().getModel(modelo).refresh(true);
		},

		// Borrar la Data General
		onCleanDataGeneral: function () {
			var oDataGeneral = oThat.getView().getModel("DataGeneral");
			oDataGeneral.getData().Operation = "";
			oDataGeneral.getData().DocumentClass = "";
			oDataGeneral.getData().Company = "";
			oDataGeneral.getData().InvoiceDate = "";
			oDataGeneral.getData().VoucherNumber = "";
			oDataGeneral.getData().Currency = "";
			oDataGeneral.getData().InvoiceReference = "";
			oDataGeneral.getData().Amount = "";
			oDataGeneral.refresh(true);
		},

		// Crear la lista de posiciones.
		onCreatedList: function () {
			try {
				sap.ui.core.BusyIndicator.show(0);
				var aFilterUser = [];
				aFilterUser.push(new Filter("WFCreatedByUser", "EQ", sCreatedByUser.toUpperCase()));
				Service.onGetDataGeneralFilters(oModelGeneral, "PRNotPurchaseOrderSet", aFilterUser).then(function (oListMaster) {
					var master = oThat.getView().byId("idLista");
					master.destroyItems();

					$.each(oListMaster.results, function (k, v) {
						if (v.RequestedOnDate) {
							v.RequestedOnDateFormat = formatter.onGetFormatDate(v.RequestedOnDate);
						} else {
							v.RequestedOnDateFormat = "";
						}

						if (v.ApprovedOnDate) {
							v.ApprovedOnDateFormat = formatter.onGetFormatDate(v.ApprovedOnDate);
						} else {
							v.ApprovedOnDateFormat = "";
						}
					});

					oListMasterGeneral = oListMaster.results;
					var oModel = new JSONModel(oListMaster.results);
					oModel.setSizeLimit(999999999);
					oThat.getView().setModel(oModel, "listMaster");
				}).catch(function (oError) {
					oThat.onErrorMessage(oError, "errorSave");
				}).finally(function () {
					sap.ui.core.BusyIndicator.hide();
				});
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Obtener la Data de Datos Generales y de los Tabs
		onGetData: function () {
			try {
				oThat.onGetConstants().then(function (oConstants) {
					var oModel = new JSONModel(oConstants.results);
					oModel.setSizeLimit(999999999);
					oThat.getView().setModel(oModel, "listConstants");
					//Se obtiene la ruta de almacenamiento de archivos
					var sValue = oConstants.results.find(oItem => {
						return oItem.Group1 === "SHAREPOINT" && oItem.Field === "ROOT_DIRECTORY";
					});
					if (sValue === undefined) {
						MessageBox.error(formatter.onGetI18nText(oThat, "msgNotRouteFolder"));
					} else {
						SharePoint.setValueRoot(sValue.ValueLow);
					}
					$.each(oConstants.results, function (k, v) {
						if (v.Field === "URL") {
							sUri = v.ValueLow;
							oThat.uri = sUri;
						}
						if (v.Field === "LANDSCAPE") {
							sAmbient = v.ValueLow;
						}
						if (v.Field === "PR_NOT_PORDER") {
							sProject = v.ValueLow;
						}
						if (v.Field === "BLART" && v.Sequence.trim() === "1") {
							oDocumentClassConst1 = v.ValueLow;
						}
						if (v.Field === "BLART" && v.Sequence.trim() === "2") {
							oDocumentClassConst2 = v.ValueLow;
						}
						if (v.Field === "ID_APPLICATION") {
							idApp = v.ValueLow;
						}
						if (v.Group1 === "XML_TAG" && v.Field === "DOCUMENT_TYPE") {
							aTag.push({
								"id": v.ValueLow,
								"text": v.ValueHigh
							});
						}
					});
					oThat.onGetOperation().then(resultado => oThat.onGetDocumentClass()).then(resultado => oThat.onGetSociety()).then(resultado =>
						oThat.onGetCoin()).then(resultado => {
						oThat.onGetMyInbox($.getComponentDataMyInbox);
						oThat.onGetDataOfNavigation();
					});
				}).catch(function (oError) {
					oThat.onErrorMessage(oError, "errorSave");
					sap.ui.core.BusyIndicator.hide();
				}).finally(function () {
					// sap.ui.core.BusyIndicator.hide();
				});
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Obtener los datos del usuario logeado del IAS.
		readUserIasInfo: function () {
			try {
				return new Promise(function (resolve, reject) {
					var userModel = new JSONModel({});
					var sMail = sap.ushell.Container.getService("UserInfo").getUser().getEmail();
					var sPath = "/iasscim/Users?filter=emails eq '" + sMail + "'";
					userModel.loadData(sPath, null, true, 'GET', null, null, {
						'Content-Type': 'application/scim+json'
					}).then(() => {
						var oDataTemp = userModel.getData();
						resolve(oDataTemp);
					}).catch(err => {
						reject("Error");
					});
				});
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Borrar todos los combos
		onAddRequestInvoice: function () {
			try {
				MessageBox.confirm(
					oThat.getView().getModel("i18n").getResourceBundle().getText("confirmAddNewRequest"), {
						styleClass: "sapUiSizeCompact",
						actions: [MessageBox.Action.YES, MessageBox.Action.NO],
						onClose: function (oAction) {
							if (oAction === "YES") {
								// Enabled en su forma inicial.
								oThat.uuid = SharePoint.getUUIDV4().toUpperCase().replace(/-/gi, '');
								oThat.onIniciatorEnabledVisible();
								oThat.onCleanDataGeneral();
								oThat.onIniciatorModels();
								oThat.onCreatedList();
								oThat.sFullPath = undefined;
								flagValidator = true;
								sEstado = "I";
								oThat.onState(false, "timeLine");
							}
						}
					}
				);
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Mensajes de error, exito, warning.
		onMessagesButtonPress: function (oEvent) {
			try {
				// var oMessagesButton = oEvent.getSource();
				// if (!oThat._messagePopover) {
				// 	oThat._messagePopover = new MessagePopover({
				// 		items: {
				// 			path: "message>/",
				// 			template: new MessagePopoverItem({
				// 				description: "{message>description}",
				// 				type: "{message>type}",
				// 				title: "{message>title}"
				// 			})
				// 		}
				// 	});
				// 	oMessagesButton.addDependent(oThat._messagePopover);
				// }
				// oThat._messagePopover.toggle(oMessagesButton);
				if (!oThat._oMessagePopover) {
					// create popover lazily (singleton)
					oThat._oMessagePopover = sap.ui.xmlfragment("onFrgMessagePopover", fragmentsPath + ".fragment.MessagePopover", oThat);
					oThat.getView().addDependent(oThat._oMessagePopover);
				}
				oThat._oMessagePopover.openBy(oEvent.getSource());
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		onMessagesButtonPressMyInbox: function (oEvent) {
			try {
				var messages = JSON.parse(sessionStorage.getItem("messages"));
				$.each(messages, function (key, item) {
					item.description = item.message;
					var type = item.severity;
					if (type == "info") {
						item.type = "Information";
					} else if (type == "warning") {
						item.type = "Warning";
					} else if (type == "success") {
						item.type = "Success";
					} else {
						item.type = "Error";
					}
				});
				var oModel = new JSONModel(messages);
				oThat.getView().setModel(oModel, "messageMyInbox");

				var oMessagesButton = oEvent;
				if (!oThat._messagePopoverMyInbox) {
					oThat._messagePopoverMyInbox = new MessagePopover({
						items: {
							path: "messageMyInbox>/",
							template: new MessagePopoverItem({
								description: "{messageMyInbox>description}",
								type: "{messageMyInbox>type}",
								title: "{messageMyInbox>title}"
							})
						}
					});
					oMessagesButton.addDependent(oThat._messagePopoverMyInbox);
				}
				oThat._messagePopoverMyInbox.setModel(oModel, "messageMyInbox");
				oThat._messagePopoverMyInbox.toggle(oMessagesButton);
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		onGetTestData: function () {
			var jDatos = sap.ui.require.toUrl("com/everis/suppliers/invoiceregisternotoc/model/dataGeneral.json");
			var oModel = new JSONModel(jDatos);
			this.getView().setModel(oModel, "listGroup");
		},

		onChooseDocumentType: function (oEvent) {
			try {
				var sDocumentType = oEvent.getSource().getSelectedKey(),
					oDataGeneral = oThat.getView().getModel("DataGeneral");

				if (sDocumentType === oDocumentClassConst1 || sDocumentType === oDocumentClassConst2) {
					oThat.onState(true, "visible");
				} else {
					oThat.onState(false, "visible");
				}

				if (sDocumentType !== "") {
					oEvent.getSource().setValueState("Success");
					oEvent.getSource().setValueStateText("");

					oDataGeneral.getData().VoucherNumber = sDocumentType + oDataGeneral.getData().VoucherNumber.slice(2);
					oThat.onState(true, "voucher");
				} else {
					oDataGeneral.getData().VoucherNumber = "";
					oThat.onState(false, "voucher");
				}

				oDataGeneral.refresh(true);
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Obtener la lista del combo de Operacion.
		onGetOperation: function () {
			try {
				return new Promise(function (resolve, reject) {
					sap.ui.core.BusyIndicator.show(0);
					Service.onGetDataGeneral(oModelGeneral, "OperationSet").then(function (oOperation) {
						var oModel = new JSONModel(oOperation.results);
						oModel.setSizeLimit(999999999);
						oThat.getView().setModel(oModel, "listOperation");
						resolve(oOperation);
					}).catch(function (oError) {
						oThat.onErrorMessage(oError, "errorSave");
						reject(oError);
						sap.ui.core.BusyIndicator.hide();
					}).finally(function () {
						// sap.ui.core.BusyIndicator.hide();
					});
				});
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Obtener la lista del combo de Clase Documento.
		onGetDocumentClass: function () {
			try {
				return new Promise(function (resolve, reject) {
					sap.ui.core.BusyIndicator.show(0);
					Service.onGetDataGeneral(oModelGeneral, "DocumentClassSet").then(function (oDocumentClass) {
						var oModel = new JSONModel(oDocumentClass.results);
						oModel.setSizeLimit(999999999);
						oThat.getView().setModel(oModel, "listDocumentClass");
						resolve(oDocumentClass);
					}).catch(function (oError) {
						oThat.onErrorMessage(oError, "errorSave");
						reject(oError);
						sap.ui.core.BusyIndicator.hide();
					}).finally(function () {
						// sap.ui.core.BusyIndicator.hide();
					});
				});
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Obtener la lista del combo de Sociedad.
		onGetSociety: function () {
			try {
				return new Promise(function (resolve, reject) {
					sap.ui.core.BusyIndicator.show(0);
					var aFilterUser = [];
					aFilterUser.push(new Filter("Application", "EQ", idApp));
					Service.onGetDataGeneralFilters(oModelGeneral, "CompanySet", aFilterUser).then(function (oSociety) {
						var oModel = new JSONModel(oSociety.results);
						oModel.setSizeLimit(999999999);
						oThat.getView().setModel(oModel, "listSociety");
						resolve(oSociety);
					}).catch(function (oError) {
						oThat.onErrorMessage(oError, "errorSave");
						reject(oError);
						sap.ui.core.BusyIndicator.hide();
					}).finally(function () {
						// sap.ui.core.BusyIndicator.hide();
					});
				});
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Obtener la lista del Combobox de moneda.
		onGetCoin: function () {
			try {
				return new Promise(function (resolve, reject) {
					sap.ui.core.BusyIndicator.show(0);
					var aFilterUser = [];
					aFilterUser.push(new Filter("Application", "EQ", idApp));
					Service.onGetDataGeneralFilters(oModelGeneral, "CurrencySet", aFilterUser).then(function (oCoin) {
						var oModel = new JSONModel(oCoin.results);
						oModel.setSizeLimit(999999999);
						oThat.getView().setModel(oModel, "listCoin");
						resolve(oCoin);
					}).catch(function (oError) {
						oThat.onErrorMessage(oError, "errorSave");
						reject(oError);
					}).finally(function () {
						sap.ui.core.BusyIndicator.hide();
					});
				});
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Obtener las constantes de SAP.
		onGetConstants: function () {
			try {
				return new Promise(function (resolve, reject) {
					sap.ui.core.BusyIndicator.show(0);
					var aFilterUser = [];
					aFilterUser.push(new Filter("Aplication", "EQ", "SCP_SUPPLIERS"));
					aFilterUser.push(new Filter("Group1", "EQ", "PR_NOT_PORDER"));
					aFilterUser.push(new Filter("Group1", "EQ", "SHAREPOINT"));
					aFilterUser.push(new Filter("Group1", "EQ", "XML_TAG"));
					aFilterUser.push(new Filter("Field", "EQ", "ROOT_DIRECTORY"));
					aFilterUser.push(new Filter("Field", "EQ", "URL"));
					aFilterUser.push(new Filter("Field", "EQ", "LANDSCAPE"));
					aFilterUser.push(new Filter("Field", "EQ", "PR_NOT_PORDER"));
					aFilterUser.push(new Filter("Field", "EQ", "BLART"));
					aFilterUser.push(new Filter("Field", "EQ", "ID_APPLICATION"));
					aFilterUser.push(new Filter("Field", "EQ", "DOCUMENT_TYPE"));
					Service.onGetDataGeneralFilters(oModelGeneral, "ConfigurationSet", aFilterUser).then(function (oConstants) {
						resolve(oConstants);
					}).catch(function (oError) {
						oThat.onErrorMessage(oError, "errorSave");
						sap.ui.core.BusyIndicator.hide();
					}).finally(function () {
						// sap.ui.core.BusyIndicator.hide();
					});
				});
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Mensaje de confirmacion para la creacion de la solicitud.
		onRequestInvoice: function () {
			try {
				MessageBox.confirm(
					formatter.onGetI18nText(oThat, "confirmRequest"), {
						styleClass: "sapUiSizeCompact",
						actions: [MessageBox.Action.YES, MessageBox.Action.NO],
						onClose: function (oAction) {
							if (oAction === "YES") {
								var oUploadFile = oThat.getView().getModel("UploadFile").getData(),
									aFiles = oThat.getView().getModel("file").getData(),
									//Colocar en esa estructura Folder1/Folder2 
									sRoute = sAmbient + "/" + sProject + "/" + sCreatedByRuc; //"DEV/SOLICITUDPROVEEDORES/20200120001"; //El ruc debe ser dinamico
								//Ruta completa donde se guardan los archivos
								oThat.sFullPath = sRoute + "/" + oThat.uuid; // en ves de ir el string en duro PRUEBA debe ir oThat.uuid o traer el uuid que se guardo

								oThat.onValidationBeforeSaveRequestInvoicenotoc();

								if (!flagValidator) {
									return false;
								}

								SharePoint.createFolderDeep(oThat, oThat.sFullPath).then(resolve => {
									// if (aFiles.length === 3) {
									if (oUploadFile.XML != "") {
										SharePoint.saveFiles(oThat, aFiles).then(response => {
											sap.ui.core.BusyIndicator.show(0);
											oThat.onSaveRequestInvoicenotoc();
										}).catch(err => {
											MessageBox.error(formatter.onGetI18nText(oThat, "sErrorAdjuntos") + " " + JSON.parse(err
												.responseText).error_description);
										});
									} else {
										MessageBox.warning(formatter.onGetI18nText(oThat, "sMissingAdjunt"));
									}
								}).catch(oError => {
									oThat.onErrorMessage(oError, "errorSave");
								});

							}
						}
					}
				);
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Crear la solicitud de preregistro sin oc.
		onSaveRequestInvoicenotoc: function () {
			try {
				sap.ui.core.BusyIndicator.show(0);
				var oDataGeneral = oThat.getView().getModel("DataGeneral"),
					DocumentNum = oDataGeneral.getData().VoucherNumber;

				oThat.onValidateDate(oDataGeneral.getData().InvoiceDate);

				var oData = {
					"PRNotPurchaseOrderID": oThat.uuid,
					"Operation": oDataGeneral.getData().Operation,
					"DocumentClass": oDataGeneral.getData().DocumentClass,
					"Company": oDataGeneral.getData().Company,
					"InvoiceDate": oDataGeneral.getData().InvoiceDate,
					"VoucherNumber": oDataGeneral.getData().VoucherNumber,
					"Currency": oDataGeneral.getData().Currency,
					"InvoiceReference": oDataGeneral.getData().InvoiceReference,
					"Amount": oDataGeneral.getData().Amount,
					"WFStatus": sEstado,
					"WFCreatedByUser": sCreatedByUser.toUpperCase(),
					"Ruc": sCreatedByRuc
				};
				Service.onRefreshToken(oModelGeneral).then(function (oRefresh) {
					Service.onSaveRequestBP(oModelGeneral, "PRNotPurchaseOrderSet", oData).then(function (oSaveRequest) {
						var messages = Message.onReadMessageSuccess(oSaveRequest, DocumentNum);
						if (messages.length > 0) {
							var oModel = new JSONModel(messages);
							oThat.getView().setModel(oModel, "message");
							MessageToast.show(formatter.onGetI18nText(oThat, "sCorrectSend"));
						} else {
							MessageBox.success(formatter.onGetI18nText(oThat, "sSaveCorrect"));
						}

						if (oThat.myInbox) {
							// Workflow.onRefreshTask();
							MessageToast.show(formatter.onGetI18nText(oThat, "sCorrectReSend"));
							sap.ui.getCore().byId(oThat.IdListMaster).getModel().refresh(true);
						} else {
							oThat.uuid = SharePoint.getUUIDV4().toUpperCase().replace(/-/gi, '');
							oThat.onIniciatorEnabledVisible();
							oThat.onCleanDataGeneral();
							oThat.onIniciatorModels();
							oThat.onCreatedList();
							oThat.sFullPath = undefined;
							flagValidator = true;
							sEstado = "I";
							oThat.onState(messages.length, "count");
						}
					}).catch(function (oError) {
						MessageToast.show(formatter.onGetI18nText(oThat, "sErrorGeneral"));
						var messages = Message.onReadMessageError(oError, DocumentNum);
						if (messages.length > 0) {
							oThat.onState(messages.length, "count");
							var oModel = new JSONModel(messages);
							oThat.getView().setModel(oModel, "message");
						} else {
							oThat.onErrorMessage(oError, "sErrorGeneral");
						}
					}).finally(function () {
						sap.ui.core.BusyIndicator.hide();
					});
				}).catch(function (oError) {
					console.log("error");
					sap.ui.core.BusyIndicator.hide();
				});
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		onValidateDate: function (date) {
			try {
				var sDateValidate = date.indexOf("T"),
					sDateValidate2 = date.indexOf("/"),
					oDataGeneral = oThat.getView().getModel("DataGeneral");
				if (sDateValidate === -1) {
					if (sDateValidate2 === -1) {
						var sDateFormatter = formatter.onGetFormatDate(date),
							sDatePartsFormatter = sDateFormatter.split("/");
						oDataGeneral.getData().InvoiceDate = sDatePartsFormatter[2] + "-" + sDatePartsFormatter[1] + "-" + sDatePartsFormatter[0] +
							"T00:00:00";
					} else {
						var sDateParts = date.split("/");
						oDataGeneral.getData().InvoiceDate = sDateParts[2] + "-" + sDateParts[1] + "-" + sDateParts[0] + "T00:00:00";
					}
				}
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		onGetRequestInvoice: function (oEvent) {
			try {
				var oItem = oEvent.getParameter("listItem").getBindingContext("listMaster").getObject();
				MessageBox.confirm(
					oThat.getView().getModel("i18n").getResourceBundle().getText("confirmGetOldRequest"), {
						styleClass: "sapUiSizeCompact",
						actions: [MessageBox.Action.YES, MessageBox.Action.NO],
						onClose: function (oAction) {
							if (oAction === "YES") {
								// Se ponen los campos en modo no editable
								oThat.onState(false, "general");
								oThat.onState(false, "documentNumber");
								// Se traeran los datos del BP seleccionado
								oThat.onGetServiceRequestInvoice(oItem.PRNotPurchaseOrderID);
							}
						}
					}
				);
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		onGetServiceRequestInvoice: function (PRNotPurchaseOrderID) {
			try {
				sap.ui.core.BusyIndicator.show(0);
				Service.onGetRequestInvoice(oModelGeneral, "PRNotPurchaseOrderSet", PRNotPurchaseOrderID).then(function (oRequestInvoice) {
					// Setear data de Datos Generales.
					oRequestInvoice.InvoiceDate = formatter.onGetFormatDate(oRequestInvoice.InvoiceDate);
					if (oRequestInvoice.DocumentClass === oDocumentClassConst1 || oRequestInvoice.DocumentClass === oDocumentClassConst2) {
						oThat.onState(true, "visible");
					} else {
						oThat.onState(false, "visible");
					}
					var oModelDataGeneral = new JSONModel(oRequestInvoice);
					oThat.getView().setModel(oModelDataGeneral, "DataGeneral");
					oThat.getView().getModel("DataGeneral").refresh(true);

					// Setear en el historial o time line.
					$.each(oRequestInvoice.History.results, function (k, v) {
						if (v.UserComment !== "") {
							v.SystemComment = v.SystemComment + "\n" + v.UserComment;
						}
					});
					var oModelHistory = new JSONModel(oRequestInvoice.History.results);
					oThat.getView().setModel(oModelHistory, "listTimeLine");
					oThat.getView().getModel("listTimeLine").refresh(true);
					oThat.onState(true, "timeLine");

					// Attachments
					var aDataFolder = oThat.getView().getModel("folder").getData();
					aDataFolder = aDataFolder.slice();

					var sPRNotPurchaseOrderID = oRequestInvoice.PRNotPurchaseOrderID;
					var sDocumentNumber = oRequestInvoice.Ruc;
					if (sPRNotPurchaseOrderID !== "" && sDocumentNumber !== "") {
						BusyIndicator.show(0);
						SharePoint.getFiles(oThat, aDataFolder, sAmbient, sProject, sDocumentNumber, sPRNotPurchaseOrderID);
					}
				}).catch(function (oError) {
					oThat.onErrorMessage(oError, "errorSave");
				}).finally(function () {
					sap.ui.core.BusyIndicator.hide();
				});
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Crear la solicitud de preregistro sin oc.
		onValidationBeforeSaveRequestInvoicenotoc: function () {
			try {
				var oDataGeneral = oThat.getView().getModel("DataGeneral"),
					rexNumber = /[^a-zA-Z0-9]/,
					regExpImport = /^\d+(\.\d{0,2})?$/;

				if (oDataGeneral.getData().Operation !== "" && oDataGeneral.getData().DocumentClass !== "" && oDataGeneral.getData().Company !==
					"" && oDataGeneral.getData().InvoiceDate !== "" && oDataGeneral.getData().VoucherNumber !== "" && oDataGeneral.getData().Currency !==
					"" && oDataGeneral.getData().Amount !== "") {

					if (!oDataGeneral.getData().Amount.match(regExpImport)) {
						oThat.getView().byId("iptAmount").setValueState("Error");
						oThat.getView().byId("iptAmount").setValueStateText(formatter.onGetI18nText(oThat, "sErrorNumber"));
						flagValidator = false;
						return;
					} else {
						oThat.getView().byId("iptAmount").setValueState("Success");
						oThat.getView().byId("iptAmount").setValueStateText("");
						flagValidator = true;
					}

					if (oDataGeneral.getData().DocumentClass === oDocumentClassConst1 || oDataGeneral.getData().DocumentClass ===
						oDocumentClassConst2) {
						if (oDataGeneral.getData().InvoiceReference === "") {
							oThat.getView().byId("iptReference").setValueState("Error");
							oThat.getView().byId("iptReference").setValueStateText(formatter.onGetI18nText(oThat, "sErrorValidator"));
							MessageBox.warning(formatter.onGetI18nText(oThat, "sValidDataNumberReference"));
							flagValidator = false;
							return;
						} else {
							oThat.getView().byId("iptReference").setValueState("Success");
							oThat.getView().byId("iptReference").setValueStateText("");
							flagValidator = true;
						}

						var sInvoiceReferenceParts = oDataGeneral.getData().InvoiceReference.split("-");
						var sInvoiceReferenceString = sInvoiceReferenceParts.join("");

						if (!rexNumber.test(sInvoiceReferenceString) && oDataGeneral.getData().InvoiceReference.length === 16) {
							flagValidator = true;
						} else {
							MessageBox.warning(formatter.onGetI18nText(oThat, "sValidDataNumberReference"));
							flagValidator = false;
							return;
						}
					}

					var sVoucherNumberParts = oDataGeneral.getData().VoucherNumber.split("-");
					var sVoucherNumberString = sVoucherNumberParts.join("");

					if (!rexNumber.test(sVoucherNumberString) && oDataGeneral.getData().VoucherNumber.length === 16) {
						flagValidator = true;
					} else {
						MessageBox.warning(formatter.onGetI18nText(oThat, "sValidDataNumberCompro"));
						flagValidator = false;
						return;
					}
				} else {
					if (oDataGeneral.getData().Operation === "") {
						oThat.getView().byId("cboOperation").setValueState("Error");
						oThat.getView().byId("cboOperation").setValueStateText(formatter.onGetI18nText(oThat, "sErrorValidator"));
					} else {
						oThat.getView().byId("cboOperation").setValueState("Success");
						oThat.getView().byId("cboOperation").setValueStateText("");
					}
					if (oDataGeneral.getData().DocumentClass === "") {
						oThat.getView().byId("cboDocumentClass").setValueState("Error");
						oThat.getView().byId("cboDocumentClass").setValueStateText(formatter.onGetI18nText(oThat, "sErrorValidator"));
					} else {
						oThat.getView().byId("cboDocumentClass").setValueState("Success");
						oThat.getView().byId("cboDocumentClass").setValueStateText("");
					}
					if (oDataGeneral.getData().Company === "") {
						oThat.getView().byId("cboSociety").setValueState("Error");
						oThat.getView().byId("cboSociety").setValueStateText(formatter.onGetI18nText(oThat, "sErrorValidator"));
					} else {
						oThat.getView().byId("cboSociety").setValueState("Success");
						oThat.getView().byId("cboSociety").setValueStateText("");
					}
					if (oDataGeneral.getData().InvoiceDate === "") {
						oThat.getView().byId("dpDate").setValueState("Error");
						oThat.getView().byId("dpDate").setValueStateText(formatter.onGetI18nText(oThat, "sErrorValidator"));
					} else {
						oThat.getView().byId("dpDate").setValueState("Success");
						oThat.getView().byId("dpDate").setValueStateText("");
					}
					if (oDataGeneral.getData().VoucherNumber === "") {
						oThat.getView().byId("iptVoucherNumber").setValueState("Error");
						oThat.getView().byId("iptVoucherNumber").setValueStateText(formatter.onGetI18nText(oThat, "sErrorValidator"));
					} else {
						oThat.getView().byId("iptVoucherNumber").setValueState("Success");
						oThat.getView().byId("iptVoucherNumber").setValueStateText("");
					}
					if (oDataGeneral.getData().Currency === "") {
						oThat.getView().byId("cboCurrency").setValueState("Error");
						oThat.getView().byId("cboCurrency").setValueStateText(formatter.onGetI18nText(oThat, "sErrorValidator"));
					} else {
						oThat.getView().byId("cboCurrency").setValueState("Success");
						oThat.getView().byId("cboCurrency").setValueStateText("");
					}
					if (oDataGeneral.getData().Amount === "") {
						oThat.getView().byId("iptAmount").setValueState("Error");
						oThat.getView().byId("iptAmount").setValueStateText(formatter.onGetI18nText(oThat, "sErrorValidator"));
					} else {
						oThat.getView().byId("iptAmount").setValueState("Success");
						oThat.getView().byId("iptAmount").setValueStateText("");
					}

					MessageBox.warning(formatter.onGetI18nText(oThat, "sValidDataGeneral"));
					flagValidator = false;
				}
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		onSaveFile: function (oEvent) {
			try {
				var oSource = oEvent.getSource();
				var sCustom = oSource.data("custom");
				var oParameters = oEvent.getParameters("files");
				var aDataFile = oThat.getView().getModel("file").getData();
				var aDataFolder = oThat.getView().getModel("folder").getData();
				var oFile = oParameters.files[0];
				var reader = new FileReader();
				// var oDataUploadAttachments = this["dialogUploadAttachments"].getModel("UploadAttachments").getData();
				if (oFile) {
					switch (sCustom) {
					case 'XML':
						reader.onloadend = function (oEventLoad) {
							var oXmlValidator = oThat.onGetXml(oEventLoad);

							if (!oXmlValidator.Valid) {
								MessageBox.error(formatter.onGetI18nText(oThat, oXmlValidator.TextI18n));
								oSource.setValue("");
							} else {
								oThat.onSaveModelFile(oEventLoad, aDataFolder, sCustom, oFile, aDataFile);
							}
						};
						reader.onerror = function (oEventError) {
							MessageToast.show(formatter.onGetI18nText(oThat, "sErrorXml"));
						};
						reader.readAsBinaryString(oFile);
						break;
					default:
						reader.onloadend = function (e) {
							oThat.onSaveModelFile(e, aDataFolder, sCustom, oFile, aDataFile);
						};
						reader.readAsArrayBuffer(oFile);
						break;
					}
				}
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		onSaveModelFile: function (oEvent, aDataFolder, sCustom, oFile, aDataFile) {
			try {
				var result = oEvent.target.result;
				// DJ : Acta de declaración jurada, SR: Solicitud de la ficha RUC, EC:Encabezado del estado de cuenta bancario
				var oFindFolder = aDataFolder.find(oItem => {
					return oItem.Id === sCustom;
				});
				var oJson = {
					Id: sCustom,
					FileName: oFile.name,
					ArrayBufferResult: result,
					FolderName: oFindFolder.Name
				};
				var oFindFile = aDataFile.find(oItem => {
					return oItem.Id === sCustom;
				});
				var bFind = true;
				if (oFindFile === undefined) {
					bFind = false;
				}

				if (bFind) {
					aDataFile.find(v => v.Id === sCustom).FileName = oFile.name;
					aDataFile.find(v => v.Id === sCustom).ArrayBufferResult = result;
				} else {
					aDataFile.push(oJson);
				}
				oThat.getView().getModel("UploadFile").setProperty("/" + oFindFolder.Id, oFile.name);
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		onGetXml: function (oEvent) {
			var oDataGeneral = oThat.getView().getModel("DataGeneral");
			var sResultFile = oEvent.target.result;
			var sTextI18n = "";
			var bError = false;
			var bValid = true;
			var oResultSplit = sResultFile.split("ï»¿");
			var oTag;
			var sTag = "";
			if (oResultSplit.length === 2) {
				sResultFile = oResultSplit[1];
			}
			sResultFile = (new DOMParser()).parseFromString(sResultFile, "text/xml");
			sResultFile = oThat.xmlToJson(sResultFile);

			$.each(aTag, function (k, v) {
				if (sResultFile[v.text] !== undefined) {
					oTag = sResultFile[v.text];
					sTag = v.id;
				}
			});

			if (oTag === undefined) {
				bValid = false;
				sTextI18n = "msginvoicetagnotfound";
				//return MessageToast.show("Etiqueta Invoice no encontrado en el XML");
			}

			if (!bValid) {
				return {
					"Valid": bValid,
					"TextI18n": sTextI18n,
					"Error": bError,
					"TextError": ""
				};
			} else {
				try {
					if (oTag["cac:AccountingSupplierParty"]["cac:Party"]["cac:PartyIdentification"] !== undefined) {
						if (oTag["cac:AccountingSupplierParty"]["cac:Party"]["cac:PartyIdentification"]["cbc:ID"]["#text"] !==
							sCreatedByRuc) {
							bValid = false;
							sTextI18n = "msgrucnotmatch";
							//return MessageToast.show("RUC no concuerda con RUC asignado al usuario.");
						}
					} else if (oTag["cac:AccountingSupplierParty"]["cbc:CustomerAssignedAccountID"]["#text"] !== sCreatedByRuc) {
						bValid = false;
						sTextI18n = "msgrucnotmatch";
						//return MessageToast.show("RUC no concuerda con RUC asignado al usuario.");
					}

					if (!bValid) {
						return {
							"Valid": bValid,
							"TextI18n": sTextI18n,
							"Error": bError,
							"TextError": ""
						};
					} else {
						if (oTag["cbc:IssueDate"] !== undefined) {
							oDataGeneral.getData().InvoiceDate = oTag["cbc:IssueDate"]["#text"] + "T00:00:00";
						} else {
							oDataGeneral.getData().InvoiceDate = "";
						}
						if (oTag["cbc:InvoiceTypeCode"] !== undefined) {
							oDataGeneral.getData().DocumentClass = oTag["cbc:InvoiceTypeCode"]["#text"];
						} else {
							oDataGeneral.getData().DocumentClass = sTag;
							oThat.onState(true, "visible");
						}
						if (oTag["cbc:ID"] !== undefined) {
							oDataGeneral.getData().VoucherNumber = oDataGeneral.getData().DocumentClass + "-" + oTag["cbc:ID"]["#text"];
						} else {
							oDataGeneral.getData().VoucherNumber = "";
						}
						if (oTag["cbc:DocumentCurrencyCode"] !== undefined) {
							oDataGeneral.getData().Currency = oTag["cbc:DocumentCurrencyCode"]["#text"];
						} else {
							oDataGeneral.getData().Currency = "";
						}
						if (oTag["cac:LegalMonetaryTotal"] !== undefined) {
							if (oTag["cac:LegalMonetaryTotal"]["cbc:PayableAmount"] !== undefined) {
								oDataGeneral.getData().Amount = parseFloat(oTag["cac:LegalMonetaryTotal"]["cbc:PayableAmount"]["#text"]).toString();
							} else {
								oDataGeneral.getData().Amount = "";
							}
						} else if (oTag["cac:RequestedMonetaryTotal"] !== undefined) {
							if (oTag["cac:RequestedMonetaryTotal"]["cbc:PayableAmount"] !== undefined) {
								oDataGeneral.getData().Amount = parseFloat(oTag["cac:RequestedMonetaryTotal"]["cbc:PayableAmount"]["#text"]).toString();
							} else {
								oDataGeneral.getData().Amount = "";
							}
						} else {
							oDataGeneral.getData().Amount = "";
						}
						if (oTag["cac:BillingReference"] !== undefined) {
							if (oTag["cac:BillingReference"]["cac:InvoiceDocumentReference"] !== undefined) {
								if (oTag["cac:BillingReference"]["cac:InvoiceDocumentReference"]["cbc:DocumentTypeCode"] !== undefined) {
									if (oTag["cac:BillingReference"]["cac:InvoiceDocumentReference"]["cbc:ID"] !== undefined) {
										oDataGeneral.getData().InvoiceReference = oTag["cac:BillingReference"]
											["cac:InvoiceDocumentReference"]["cbc:DocumentTypeCode"]["#text"] + "-" + oTag["cac:BillingReference"]
											["cac:InvoiceDocumentReference"]["cbc:ID"]["#text"];
									} else {
										oDataGeneral.getData().InvoiceReference = "";
									}
								}
							} else {
								oDataGeneral.getData().InvoiceReference = "";
							}
						} else {
							oDataGeneral.getData().InvoiceReference = "";
						}

						oDataGeneral.refresh(true);

						if (oDataGeneral.getData().InvoiceReference !== "") {
							oThat.getView().byId("iptReference").fireChange();
						}

						if (oDataGeneral.getData().VoucherNumber !== "") {
							oThat.getView().byId("iptVoucherNumber").fireChange();
							oThat.onState(true, "voucher");
						}

						return {
							"Valid": bValid,
							"TextI18n": sTextI18n,
							"Error": bError,
							"TextError": ""
						};
					}
				} catch (err) {
					return MessageToast.show(err.message);
				}
			}
		},

		xmlToJson: function (e) {
			try {
				var t = {};
				if (e.nodeType === 1) {
					if (e.attributes.length > 0) {
						t["@attributes"] = {};
						for (var a = 0; a < e.attributes.length; a++) {
							var r = e.attributes.item(a);
							t["@attributes"][r.nodeName] = r.nodeValue;
						}
					}
				} else if (e.nodeType === 3) {
					t = e.nodeValue;
				}
				if (e.hasChildNodes()) {
					for (var o = 0; o < e.childNodes.length; o++) {
						var s = e.childNodes.item(o);
						var i = s.nodeName;
						if (typeof t[i] === "undefined") {
							t[i] = this.xmlToJson(s);
						} else {
							if (typeof t[i].push === "undefined") {
								var n = t[i];
								t[i] = [];
								t[i].push(n);
							}
							t[i].push(this.xmlToJson(s));
						}
					}
				}
				return t;
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		onReferenceChange: function (oEvent) {
			try {
				var oSource = oEvent.getSource();
				var sCustom = oSource.data("custom");
				var sValor = oSource.getValue().toUpperCase().replace(/\s/g, "");
				var sValorParts = sValor.split("-");
				var sValorString = sValorParts.join("");
				var sValorFormatter = "";
				var oDataGeneral = oThat.getView().getModel("DataGeneral");
				oDataGeneral.getData().VoucherNumber = oDataGeneral.getData().DocumentClass + oDataGeneral.getData().VoucherNumber.slice(2);
				if (sValorParts.length === 3 && sValorParts[1].length === 4) {
					if (!/[^a-zA-Z0-9]/.test(sValorString)) {
						if (!/[a-zA-Z]/.test(sValorString)) {
							oSource.setValue("");
							return MessageBox.error(formatter.onGetI18nText(oThat, "msgFormatForElectronicSupplier") + sValorParts[1]);
						}
						sValorFormatter = formatter.onGetFormatReference(sValor);
						// if (sCustom === "invoiceReference") {
						// 	oThat.onValidateReference(sValorFormatter, oSource);
						// }
						oSource.setValue(sValorFormatter);
						if (oEvent.getParameters().value !== "") {
							oSource.setValueState("Success");
							oSource.setValueStateText("");
						}
					} else {
						return MessageToast.show(formatter.onGetI18nText(oThat, "msgformatterinvoicespecial"));
					}
				} else {
					return MessageToast.show(formatter.onGetI18nText(oThat, "msgformatterinvoice"));
				}
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		onValidateReference: function (sValorFormatter, oSource) {
			try {
				BusyIndicator.show(0);
				var sPath = oModelGeneral.createKey("/ReferenceSet", {
					Xblnr: sValorFormatter,
					Nif: sCreatedByRuc
				});
				Service.consult(oModelGeneral, sPath).then(response => {
					BusyIndicator.hide();
					oThat.invoiceAlreadyRegistered(response, oSource);
				}).catch(err => {
					BusyIndicator.hide();
					oThat.onErrorMessage(err, "errorSave");
				});
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		invoiceAlreadyRegistered: function (oResponse, oSource) {
			if (oResponse.Response === "") {
				MessageBox.error(formatter.onGetI18nText(oThat, "msginvoicealreadyregistered"));
				oSource.setValue("");
				return;
			}
		},

		// Mensajes de error.
		onErrorMessage: function (oError, textoI18n) {
			try {
				if (oError.responseJSON) {
					if (oError.responseJSON.error) {
						MessageBox.error(oError.responseJSON.error.message.value);
					} else {
						if (oError.responseJSON[0]) {
							if (oError.responseJSON[0].description) {
								MessageBox.error(oError.responseJSON[0].description);
							} else {
								MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText(textoI18n));
							}
						} else {
							MessageBox.error(oError.responseJSON.response.description);
						}
					}
				} else if (oError.message) {
					MessageBox.error(oError.message);
				} else if (oError.responseText) {
					MessageBox.error(oError.responseText);
				} else {
					MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText(textoI18n));
				}
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		onValidatorColumns: function (oEvent) {
			if (oEvent.getParameters().value !== "") {
				oEvent.getSource().setValueState("Success");
				oEvent.getSource().setValueStateText("");
			}
		},

		// Busqueda de la lista master.
		onSearchMaster: function (oEvent) {
			try {
				var sValue = oThat.getView().getModel("search"),
					sQuery = sValue.getData().value,
					oListMaster = JSON.parse(JSON.stringify(oListMasterGeneral)),
					oModel = "",
					oListFilterMaster = [],
					master = oThat.getView().byId("idLista");

				master.destroyItems();

				if (sQuery !== "") {
					// update list binding
					oListFilterMaster = oListMaster.filter(function (item) {
						if (item.WFCreatedByName.toUpperCase().indexOf(sQuery.toUpperCase()) > -1 || item.WFStatus.toUpperCase().indexOf(sQuery.toUpperCase()) >
							-1 || item.Ruc.toUpperCase().indexOf(sQuery.toUpperCase()) > -1 || item.RequestedOnDateFormat.toUpperCase().indexOf(sQuery.toUpperCase()) >
							-1 || item.ApprovedOnDateFormat.toUpperCase().indexOf(
								sQuery.toUpperCase()) > -1) {
							return item;
						}
					});

					oModel = new JSONModel(oListFilterMaster);
					oModel.setSizeLimit(999999999);
					oThat.getView().setModel(oModel, "listMaster");
					oThat.getView().getModel("listMaster").refresh(true);
				} else {
					oModel = new JSONModel(oListMasterGeneral);
					oModel.setSizeLimit(999999999);
					oThat.getView().setModel(oModel, "listMaster");
					oThat.getView().getModel("listMaster").refresh(true);
				}
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Descargar los archivos.
		onDowloadFormat: function (oEvent) {
			try {
				var oSource = oEvent.getSource();
				var sCustom = oSource.data("custom");
				var aDataFolder = oThat.getView().getModel("folder").getData();
				aDataFolder = aDataFolder.slice();
				var oFindFolder = aDataFolder.find(oItem => {
					return oItem.Id === sCustom;
				});

				SharePoint.downloadFile(oThat, oFindFolder.Name);
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Descargar los archivos.
		onDowloadFile: function (oEvent) {
			try {
				var oSource = oEvent.getSource();
				var sCustom = oSource.data("custom");
				var aDataFolder = oThat.getView().getModel("folder").getData();
				aDataFolder = aDataFolder.slice();
				var oFindFolder = aDataFolder.find(oItem => {
					return oItem.Id === sCustom;
				});
				var oDataGeneral = oThat.getView().getModel("DataGeneral").getData();
				oDataGeneral = Object.assign({}, oDataGeneral);
				var sPRNotPurchaseOrderID = oDataGeneral.PRNotPurchaseOrderID;
				var sDocumentNumber = sCreatedByRuc;
				if (sPRNotPurchaseOrderID !== "" && sDocumentNumber !== "") {
					var sFolder = sAmbient + "/" +
						sProject + "/" + sDocumentNumber + "/" + sPRNotPurchaseOrderID + "/" +
						oFindFolder.Name;
					SharePoint.downloadFile(oThat, sFolder);
				}
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		onChangeImport: function (oEvent) {
			try {
				var rexNumber = /^\d+(\.\d{0,2})?$/;
				if (!oEvent.getParameters().value.match(rexNumber)) {
					// MessageBox.error(oEvent.getParameters().value + " " + oThat.getView().getModel("i18n").getResourceBundle().getText(
					// 	"sErrorNumber"));
					oEvent.getSource().setValueState("Error");
					oEvent.getSource().setValueStateText(oThat.getView().getModel("i18n").getResourceBundle().getText(
						"sErrorNumber"));
				} else {
					oEvent.getSource().setValueState("Success");
					oEvent.getSource().setValueStateText("");
				}
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Obtener contexto del workflow y setear valores.
		onGetMyInbox: function (getComponentDataMyInbox) {
			try {
				sap.ui.core.BusyIndicator.show(0);
				var sIdSplit = oThat.createId("idsplit");
				var oSplit = document.getElementById(sIdSplit);
				var oChild = oSplit.firstElementChild;
				var startupParameters = getComponentDataMyInbox === undefined ? undefined : getComponentDataMyInbox.startupParameters;
				//valida si entra por el workflow
				oThat.myInbox = false;
				if (startupParameters !== undefined && startupParameters.hasOwnProperty("taskModel")) {
					oThat.onGetButtonsMassive();
					oThat.myInbox = true;
					var taskModel = startupParameters.taskModel;
					var taskData = taskModel.getData();

					Workflow.onGetContextWorkflow(taskData).then(function (oContextWorkflow) {
						if (oContextWorkflow.prnRequestData !== undefined) {
							oThat.onGetServiceRequestInvoice(oContextWorkflow.prnRequestData.PRNOTPURCHASEORDERID);
						}
						oContextWorkflow.task = {};
						oContextWorkflow.task.Title = taskData.TaskTitle;
						oContextWorkflow.task.Priority = taskData.Priority;
						oContextWorkflow.task.Status = taskData.Status;

						if (taskData.Priority === "HIGH") {
							oContextWorkflow.task.PriorityState = "Warning";
						} else if (taskData.Priority === "VERY HIGH") {
							oContextWorkflow.task.PriorityState = "Error";
						} else {
							oContextWorkflow.task.PriorityState = "Success";
						}
						oContextWorkflow.task.CreatedOn = taskData.CreatedOn.toDateString();

						if (oContextWorkflow.status === "P" || oContextWorkflow.status === "T") {
							// Button Reject
							var oNegativeAction = {
								sBtnTxt: oThat.getView().getModel("i18n").getResourceBundle().getText("btnReject"),
								onBtnPressed: function () {
									oThat.onRejectRequestInvoice();
								}
							};

							// Button Approve
							var oPositiveAction = {
								sBtnTxt: oThat.getView().getModel("i18n").getResourceBundle().getText("btnApprove"),
								onBtnPressed: function () {
									sessionStorage.setItem("messages", null);
									oThat.onApproveRejectRequestInvoice("A", "", oContextWorkflow.prnRequestData.PRNOTPURCHASEORDERID, oContextWorkflow.prnRequestData
										.VOUCHERNUMBER);
								}
							};

							// Add the Approve & Reject buttons
							startupParameters.inboxAPI.addAction({
								action: oPositiveAction.sBtnTxt,
								label: oPositiveAction.sBtnTxt,
								type: "Accept"
							}, oPositiveAction.onBtnPressed);

							startupParameters.inboxAPI.addAction({
								action: oNegativeAction.sBtnTxt,
								label: oNegativeAction.sBtnTxt,
								type: "Reject"
							}, oNegativeAction.onBtnPressed);

							oThat.onState(false, "visible");
							oThat.onState(true, "timeLine");
							oThat.onState(false, "general");
							oThat.onState(false, "voucher");
						} else {
							// Button Reenvio
							var oRequestAction = {
								sBtnTxt: oThat.getView().getModel("i18n").getResourceBundle().getText("btnReRequestBP"),
								onBtnPressed: function () {
									oThat.onRequestInvoice();
								}
							};

							//Acciones del boton rechazar.
							startupParameters.inboxAPI.addAction({
								action: oRequestAction.sBtnTxt,
								label: oRequestAction.sBtnTxt,
								type: "Accept"
							}, oRequestAction.onBtnPressed);

							sEstado = "T";
							oThat.onIniciatorEnabledVisible();
							oThat.onState(true, "visible");
							oThat.onState(true, "timeLine");
							oThat.onState(true, "general");
							oThat.onState(true, "voucher");
							oThat.uuid = oContextWorkflow.prnRequestData.PRNOTPURCHASEORDERID;
						}

						// Button Messages
						var oMessageAction = {
							sBtnTxt: oThat.getView().getModel("i18n").getResourceBundle().getText("btnMessage"),
							onBtnPressed: function (oEvent) {
								var oMessagesButton = oEvent.getSource();
								oThat.onMessagesButtonPressMyInbox(oMessagesButton);
							}
						};

						//Acciones del boton Mensaje.
						startupParameters.inboxAPI.addAction({
							action: oMessageAction.sBtnTxt,
							label: oMessageAction.sBtnTxt,
							type: "Emphasized"
						}, oMessageAction.onBtnPressed);

						startupParameters.inboxAPI.getDescription("NA", taskData.InstanceID).done(function (dataDescr) {
							oContextWorkflow.task.Description = dataDescr.Description;
							var oModel = new JSONModel(oContextWorkflow);
							oThat.getView().setModel(oModel, "contextData");
						}).fail(function (errorText) {
							jQuery.sap.require("sap.m.MessageBox");
							sap.m.MessageBox.error(errorText, {
								title: "Mensaje de error"
							});
						});

						oThat.onHiddenButtonsFooter();
					}).catch(function (oError) {
						oThat.onErrorMessage(oError, "errorSave");
					}).finally(function () {
						sap.ui.core.BusyIndicator.hide();
					});
				} else {
					sap.ui.core.BusyIndicator.hide();
				}
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},
		//Obtiene el business key de la navegacion y carga la data
		onGetDataOfNavigation: function () {
			var sBusinessKey;
			var startupParams = oThat.getOwnerComponent().getComponentData().startupParameters; // get Startup params from Owner Component
			if ((startupParams.businessKey && startupParams.businessKey[0])) {
				if (startupParams.businessKey !== undefined) {
					sBusinessKey = startupParams.businessKey;
				} else {
					sBusinessKey = startupParams.businessKey[0];
				}
				oThat.onGetServiceRequestInvoice(sBusinessKey);
			}
		},
		// Comentario para el rechazo.
		onRejectRequestInvoice: function () {
			try {
				MessageBox.confirm(oThat.getView().getModel("i18n").getResourceBundle().getText("reCancelRequest"), {
					title: "Confirmacion",
					actions: ["Si", "No"],
					onClose: function (sActionClicked) {
						if (sActionClicked === 'Si') {
							var dialog = new Dialog({
								title: 'Comentario',
								type: 'Message',
								//actions: ["Aceptar", "Cancelar"],
								content: [
									new Label({
										text: oThat.getView().getModel("i18n").getResourceBundle().getText("reCancelMotivo"),
										labelFor: 'textarea'
									}),
									new TextArea('textarea', {
										liveChange: function (oEvent) {
											MotivoNotificacion = oEvent.getParameter('value');
											var parent = oEvent.getSource().getParent();

											parent.getBeginButton().setEnabled(MotivoNotificacion.length > 0);
										},
										width: '100%',
										placeholder: 'Comentario...',
										rows: 5,
										cols: 20,
										maxLength: 40
											//value: v1.COMMENTS
									})
								],
								beginButton: new Button({
									text: 'Aceptar',
									enabled: false,
									press: function () {
										dialog.close();
										var oContext = oThat.getView().getModel("contextData");
										sessionStorage.setItem("messages", null);
										oThat.onApproveRejectRequestInvoice("R", MotivoNotificacion, oContext.getData().prnRequestData.PRNOTPURCHASEORDERID,
											oContext.getData().prnRequestData.VOUCHERNUMBER);
									}
								}),
								endButton: new Button({
									text: 'Cancelar',
									press: function () {
										dialog.close();
										sap.ui.core.BusyIndicator.hide();
									}
								}),
								afterClose: function () {
									dialog.destroy();
									sap.ui.core.BusyIndicator.hide();
								}
							});
							dialog.open();
						}
					}
				});
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Refrescar la lista master.
		onRefreshRequestBP: function () {
			oThat.onCreatedList();
			var oModelSearch = new JSONModel([]);
			oThat.getView().setModel(oModelSearch, "search");
		},

		// Aprobar o rechazar la solicitud.
		onApproveRejectRequestInvoice: function (status, comment, PRNotPurchaseOrderID, DocumentNumber) {
			try {
				sap.ui.core.BusyIndicator.show(0);
				Service.onRefreshToken(oModelGeneral).then(function (oRefresh) {
					var oContext = oThat.getView().getModel("contextData");
					var oData = {
						"WFStatus": status,
						"WFCreatedByUser": sCreatedByUser,
						"WFUserComment": comment
					};

					$.ajax({
						type: "GET",
						url: "/bpmworkflowruntime/v1/xsrf-token",
						headers: {
							"X-CSRF-Token": "Fetch"
						},
						success: function (data, statusText, xhr) {
							console.log(xhr.getResponseHeader("X-CSRF-Token"));
							Service.onApproveRequestInvoice(oModelGeneral, oData, "PRNotPurchaseOrderSet", PRNotPurchaseOrderID).then(function (
								oApproveReject) {
								// sessionStorage.setItem("messages", null);
								//Workflow.onRefreshTask();
								MessageToast.show(formatter.onGetI18nText(oThat, "sCorrectApproveReject"));
								var messages = Message.onReadMessageSuccess(oApproveReject, DocumentNumber);
								if (messages.length > 0) {
									oThat.onState(messages.length, "count");
									var oModel = new JSONModel(messages);
									oThat.getView().setModel(oModel, "message");
									// oThat.onMessageStrip(messages);
									if (sessionStorage.getItem("messages") === null || sessionStorage.getItem("messages") === "null") {
										sessionStorage.setItem("messages", JSON.stringify(messages));
									} else {
										var messagesSessionStorage = JSON.parse(sessionStorage.getItem("messages"));
										var cantidadData = messagesSessionStorage.length;
										messagesSessionStorage = messagesSessionStorage.concat(messages);
										sessionStorage.setItem("messages", JSON.stringify(messagesSessionStorage));
									}
								} else {
									MessageBox.success(oThat.getView().getModel("i18n").getResourceBundle().getText("sSaveCorrect"));
								}
								sap.ui.core.BusyIndicator.hide();
							}).catch(function (oError) {
								// sessionStorage.setItem("messages", null);
								var messages = Message.onReadMessageError(oError, DocumentNumber);
								if (messages.length > 0) {
									oThat.onState(messages.length, "count");
									var oModel = new JSONModel(messages);
									oThat.getView().setModel(oModel, "message");
									// oThat.onMessageStrip(messages);
									if (sessionStorage.getItem("messages") === null || sessionStorage.getItem("messages") === "null") {
										sessionStorage.setItem("messages", JSON.stringify(messages));
									} else {
										var messagesSessionStorage = JSON.parse(sessionStorage.getItem("messages"));
										var cantidadData = messagesSessionStorage.length;
										messagesSessionStorage = messagesSessionStorage.concat(messages);
										sessionStorage.setItem("messages", JSON.stringify(messagesSessionStorage));
									}
								} else {
									oThat.onErrorMessage(oError, "sErrorReject");
								}
								sap.ui.core.BusyIndicator.hide();
							}).finally(function (err) {
								// OJO: Probar con el otro refresh!.
								sap.ui.getCore().byId(oThat.IdListMaster).getModel().refresh(true);
								// Workflow.onRefreshTask();
								// sap.ui.core.BusyIndicator.hide();
							});
						},
						error: function (errMsg) {
							console.log(errMsg.statusText);
						},
						contentType: "application/json"
					});

				}).catch(function (oError) {
					console.log("error");
					sap.ui.core.BusyIndicator.hide();
				}).finally(function () {
					// sap.ui.core.BusyIndicator.hide();
				});
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Mostrar los botones del masivo y su logica.
		onGetButtonsMassive: function () {
			try {
				if ($.getComponentDataMyInbox !== undefined && $.getComponentDataMyInbox.startupParameters.hasOwnProperty("taskModel")) {
					var sIdPrincipal = document.getElementById("application-WorkflowTask-DisplayMyInbox-content");
					if (!sIdPrincipal) { // FLP Sandbox
						sIdPrincipal = document.getElementById("application-fioriHtmlBuilder-display-content");
					}
					var sIdEdit = sIdPrincipal.childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[1].childNodes[0].childNodes[
						0].childNodes[
						0].childNodes[0].childNodes[2].childNodes[0].id;
					var sIdList = sIdPrincipal.childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[1].childNodes[0].childNodes[
						0].childNodes[2].childNodes[0].id;
					var sBar = sIdPrincipal.childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[1].childNodes[0].childNodes[
						0].childNodes[3].childNodes[0].id;
					oThat.IdListMaster = sIdList;
					sap.ui.getCore().byId(sIdList).attachSelectionChange(function (oData, oEvent, oListener) {
						if (oData.oSource.oPropagatedProperties.oModels.undefined.aTaskDefinitionIDFilterKeys) {
							if (oData.oSource.oPropagatedProperties.oModels.undefined.aTaskDefinitionIDFilterKeys[0].split("@")[1] === "wfsuppliers") {
								var aItems = sap.ui.getCore().byId(sIdList).getSelectedItems();
								if (aItems.length > 0) {
									if (aItems[0].getParent().getMode() === "MultiSelect") {
										if (sap.ui.getCore().byId("PositiveCustom") === undefined) {
											sap.ui.getCore().byId(sBar).addContentLeft(new sap.m.Button("PositiveCustom", {
												text: oThat.getView().getModel("i18n").getResourceBundle().getText("btnApprove"),
												type: "Accept",
												visible: false,
												press: function (oEvent) {
													var aSelectedItems = sap.ui.getCore().byId(sIdList).getSelectedItems();
													var aItems = [];

													for (var i = 0; i < aSelectedItems.length; i++) {
														var oSelectedItem = aSelectedItems[i].getBindingContext().getObject();
														aItems.push(oSelectedItem);
													}
													BusyIndicator.show(0);

													function positiveItems(aItems) {
														if (aItems.length > 0) {
															// var oItems = aItems.pop();
															// oThat._triggerComplete(oItems.InstanceID, true).then(function (resolve) {
															// 	positiveItems(aItems);
															// });
															sessionStorage.setItem("messages", null);
															$.each(aItems, function (k, v) {
																Workflow.onGetContextWorkflow(v).then(function (oContextWorkflow) {
																	oThat.onApproveRejectRequestBP("A", "", oContextWorkflow.bpRequestData.BPREQUESTID, oContextWorkflow.bpRequestData
																		.DOCUMENTNUMBER);
																}).catch(function (oError) {
																	oThat.onErrorMessage(oError, "errorSave");
																}).finally(function () {
																	sap.ui.core.BusyIndicator.hide();
																});
															});
														} else {
															BusyIndicator.hide();
														}
													}
													positiveItems(aItems);
												}

											}));

										}
										if (sap.ui.getCore().byId("RejectCustom") === undefined) {
											sap.ui.getCore().byId(sBar).addContentLeft(new sap.m.Button("RejectCustom", {
												text: oThat.getView().getModel("i18n").getResourceBundle().getText("btnReject"),
												type: "Reject",
												visible: false,
												press: function (oEvent) {
													var aSelectedItems = sap.ui.getCore().byId(sIdList).getSelectedItems();
													var aItems = [];

													for (var i = 0; i < aSelectedItems.length; i++) {
														var oSelectedItem = aSelectedItems[i].getBindingContext().getObject();
														aItems.push(oSelectedItem);
													}
													BusyIndicator.show(0);

													function positiveItems(aItems) {
														if (aItems.length > 0) {
															// var oItems = aItems.pop();
															// oThat._triggerComplete(oItems.InstanceID, false).then(function (resolve) {
															// 	positiveItems(aItems);
															// });
															oThat.onRejectRequestBPMasivo(aItems);
														} else {
															BusyIndicator.hide();
														}
													}
													positiveItems(aItems);
												}
											}));
										}
										if (sap.ui.getCore().byId("RejectCustom") !== undefined) {
											sap.ui.getCore().byId("RejectCustom").setVisible(false);
										}
										if (sap.ui.getCore().byId("PositiveCustom") !== undefined) {
											sap.ui.getCore().byId("PositiveCustom").setVisible(false);
										}
										if (aItems.length > 0 && sap.ui.getCore().byId("RejectCustom") !== undefined && sap.ui.getCore().byId("PositiveCustom") !==
											undefined) {
											sap.ui.getCore().byId("RejectCustom").setVisible(true);
											sap.ui.getCore().byId("PositiveCustom").setVisible(true);
										}
									} else {
										if (sap.ui.getCore().byId("RejectCustom") !== undefined) {
											sap.ui.getCore().byId("RejectCustom").setVisible(false);
										}
										if (sap.ui.getCore().byId("PositiveCustom") !== undefined) {
											sap.ui.getCore().byId("PositiveCustom").setVisible(false);
										}
									}
								}
							} else {
								MessageToast.show(formatter.onGetI18nText(oThat, "sMassiveFalse"));
							}
						}
					});
				}
			} catch (oError) {
				oThat.onErrorMessage(oError, "errorSave");
			}
		},

		// Ocultar botones de Visualizar log, Reclamar y compartir.
		onHiddenButtonsFooter: function () {
			var sIdPrincipal = document.getElementById("application-WorkflowTask-DisplayMyInbox-content");
			if (!sIdPrincipal) { // FLP Sandbox
				sIdPrincipal = document.getElementById("application-fioriHtmlBuilder-display-content");
			}
			var sButtons = sIdPrincipal.childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes[2].childNodes[0].childNodes[
				0].childNodes[2].childNodes[0].childNodes[2];

			var sButtonLog = sButtons.childNodes[0].dataset.sapUi;
			var sButtonLogParts = sButtonLog.split("--")[1];
			if (sButtonLogParts) {
				if (sButtonLogParts === "LogButtonID") {
					var sButtonLog = sButtons.childNodes[0].dataset.sapUi;
					var sButtonClaim = sButtons.childNodes[1].id;
					var sButtonShare = sButtons.childNodes[2].dataset.sapUi;
				} else {
					var sButtonLog = sButtons.childNodes[3].dataset.sapUi;
					var sButtonClaim = sButtons.childNodes[4].id;
					var sButtonShare = sButtons.childNodes[6].dataset.sapUi;
				}
			}

			sap.ui.getCore().byId(sButtonLog).setVisible(false);
			document.getElementById(sButtonClaim).setAttribute("visible", false);
			sap.ui.getCore().byId(sButtonShare).setVisible(false);
		}
	});
});