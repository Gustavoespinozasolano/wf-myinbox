sap.ui.define([
	"../controller/BaseController",
	"../service/Workflow",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/ui/core/BusyIndicator"
], function (BaseController, WF, MessageToast, MessageBox, JSONModel, Formatter, BusyIndicator) {
	"use strict";

	return BaseController.extend("com.everis.suppliers.approvalmonitor.controller.Home", {
		onInit: function () {
			var oModel = new JSONModel([]);
			this.getView().setModel(oModel);
			this.oTable = this._byId("tblReporteSolicitudes");
		},
		onSearchRequestByFilter: function () {
			var that = this;
			var oModelGlobal = this.getView().getModel("ModelGlobal");
			if (oModelGlobal.getProperty("/ApplicationKey") === "") {
				return MessageBox.error(this.getI18nText("msgSelectedApplication"));
			}
			if (oModelGlobal.getProperty("/RequestDate/From") === null || oModelGlobal.getProperty("/RequestDate/UpTo") === null) {
				return MessageBox.error(this.getI18nText("msgSelectedRequestDate"));
			}
			var sFilters = that.getFilters();
			BusyIndicator.show(0);
			WF._fetchToken().then(response => {
				WF.getInstances(sFilters).then(response => {
					//that.setProperty("ModelGlobal", "Instances");
					that.orderedDating(response, oModelGlobal.getProperty("/ApplicationKey"));
					//that.getView().setData(aData);
				}).catch(err => {
					BusyIndicator.hide();
					MessageBox.error(String(err));
				});
			}).catch(err => {
				BusyIndicator.hide();
				MessageBox.error(String(err));
			});
		},
		orderedDating: function (aData, sApplicationKey) {
			try {
				var aOrderedDating = [];
				var aApplication = this.getView().getModel("ModelGlobal").getProperty("/Application");
				var aStatus = this.getView().getModel("ModelGlobal").getProperty("/Status");
				var oApplication = aApplication.find(oItem => {
					return oItem.Id === sApplicationKey;
				});
				for (var i = 0; i < aData.length; i++) {
					var oData = aData[i];
					var sRequestingUser = oData.attributes.find(oItem => {
						return oItem.id === "RequestingUser";
					});
					if (sRequestingUser === undefined) {
						continue;
					}
					var sReason = oData.attributes.find(oItem => {
						return oItem.id === "Reason";
					});
					var sLastApprover = oData.attributes.find(oItem => {
						return oItem.id === "LastApprover";
					});
					var oState = aStatus.find(oItem => {
						return oItem.Id === oData.status;
					});
					var oOrderedDating = {
						"Application": oApplication.Name,
						"ApplicationId": oData.definitionId,
						"RequestingUser": sRequestingUser.value,
						"RequestDate": oData.startedAt.split("T")[0],
						"CompletedDate": oData.completedAt === null ? "" : oData.completedAt.split("T")[0],
						"Reason": oData.status === "COMPLETED" ? "" : sReason.value,
						"State": oState.Description,
						"BusinessKey": oData.businessKey,
						"LastApprover": sLastApprover.value,
						"Color": oState.Color
					};
					aOrderedDating.push(oOrderedDating);
				}
				this.getView().getModel().setData(aOrderedDating);
				BusyIndicator.hide();
			} catch (err) {
				BusyIndicator.hide();
				MessageBox.error(String(err));
			}

		},
		getFilters: function () {
			var oModelGlobal = this.getView().getModel("ModelGlobal");
			var sFilters = "";
			if (oModelGlobal.getProperty("/StatusKey") === "") {
				sFilters = "&status=RUNNING,COMPLETED";
			} else {
				sFilters = "&status=" + oModelGlobal.getProperty("/StatusKey");
			}
			sFilters = sFilters + "&definitionId=" + oModelGlobal.getProperty("/ApplicationKey");
			sFilters = sFilters + "&startedFrom=" + Formatter.dateFormat(oModelGlobal.getProperty("/RequestDate/From")) + "&startedUpTo=" +
				Formatter.dateFormat(oModelGlobal.getProperty(
					"/RequestDate/UpTo"));
			return sFilters;
		},
		onPressRow: function (oEvent) {
			var oSource = oEvent.getSource();
			var aApplication = this.getView().getModel("ModelGlobal").getProperty("/Application");
			var oRow = oSource.getBindingContext().getObject();
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
			var oAppNavigate = aApplication.find(oItem => {
				return oItem.Id === oRow.ApplicationId;
			});
			MessageBox.confirm("Desea ver el detalle?", {
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === MessageBox.Action.OK) {
						var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
							target: {
								semanticObject: oAppNavigate.SemanticObject,
								action: oAppNavigate.Action
							},
							params: {
								"businessKey": oRow.BusinessKey
							}
						})) || ""; // generate the Hash to display a Supplier
						oCrossAppNavigator.toExternal({
							target: {
								shellHash: hash
							}
						});
					}
				}
			});
		}

	});
});