sap.ui.define([
	"com/everis/suppliers/approvalmonitor/test/unit/controller/Home.controller"
], function () {
	"use strict";
});