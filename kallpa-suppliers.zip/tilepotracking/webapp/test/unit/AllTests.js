sap.ui.define([
	"com/everis/suppliers/tilepotracking/test/unit/controller/App.controller"
], function () {
	"use strict";
});