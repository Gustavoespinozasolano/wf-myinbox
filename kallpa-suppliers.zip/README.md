# everis-suppliers

Portal de Proveedores Front

## Despliegue

### Requisitos antes del despliegue

1. Tener los siguientes entitlements en la subaccount:

-   Portal
-   Application Runtime
-   Connectivity
-   Destination
-   HTML5 Applications
-   Workflow
-   UI Theme Designer

2. Crear un System user en el administrador del IAS y colocarle una contraseña. Ver [documentación](https://help.sap.com/viewer/6d6d63354d1242d185ab4830fc04feb1/Cloud/en-US/e3f31bdf55c5454c86a479c6384498a5.html).

3. Revisar los destinos, ya que probablemente varíen de un ambiente a otro. Por ejemplo, en este repo el destino que apunta al S/4HANA ES4 de everis es `Everis`.
   Actualmente se tienen mapeados los siguientes:

-   KAG_S4H_HTTP_BASIC
-   IAS_SCIM_API
-   bpmworkflowruntime_mail

4. Llenar tabla de constantes (`/EPER/TCONSTANTS`).

    1. El client id y secret de Workflow se obtienen del service key del workflow instance.
    2. El user/password de IAS son los mismos que los configurados en el destination IAS_SCIM_API (system user administrator).

5. Registrar object y subobject de log en la tx. ´SLG0´:
    - Objeto: /EPER/SUPPLIERS
    - Subobjetos:
        - BP_REQUEST: Solicitud de creación Business Partner
        - PR_NOT_PORDER: Pre register without purchase order

### Pasos para despliegue

-   Hacer build y despliegue del Workflow para la app BP Creation Request (repo: https://github.com/everis-scp/everis-suppliers-bp-workflow)
-   Crear una instancia de "app-host" con el nombre `suppliers_html5_repo_host` y actualizarlo con la config. `{"sizeLimit": 8}`. Para mas detalle, ver [esta documentación](https://github.com/everis-scp/scp-documentation/blob/master/scp/cf/cf.md#sizelimit-html5-repo-host). Esto sólo se hace para el primer despliegue.
-   Clonar repo en Web IDE
-   Hacer Build de todo el proyecto y desplegarlo

### Pasos pos-despliegue

-   Asignar permisos a workflow instance service. Ver [documentación](https://github.com/everis-scp/scp-documentation/blob/master/workflow-cf/wf.md#permisos). Por ejemplo:

    `cf update-service workflow_service -c "scopes.json"`

-   Configurar IAS:
    -   Descargar metadata IAS: Tenant Settings > SAML 2.0 Configuration > Download Metadata File
    -   En SCP, ir a Trust Configuration y añadir metadata IAS
    -   En IAS, añadir una nueva Application
    -   Añadir SAML 2.0 Configuration (descargar metadata de SCP > Trust Configuration > SAML Metadata) y setear Algorithm a `SHA-256`
    -   Cambiar Subject Identifier a Login Name
    -   Agregar Assertion Attribute: Groups > Groups (respetar mayúsculas)
-   Crear Role Collections
    -   Suppliers_BP_Aprobador
    -   Suppliers_BP_Proveedor
    -   Suppliers_Admin
    -   Suppliers_Inicial
-   Crear Role Collection Mappings en Trust Configuration

### Otros

-   [Documentación de Roles necesarios para Workflow tiles](https://help.sap.com/viewer/e157c391253b4ecd93647bf232d18a83/Cloud/en-US/103f2b307af142e5a91368c1539dea57.html)
