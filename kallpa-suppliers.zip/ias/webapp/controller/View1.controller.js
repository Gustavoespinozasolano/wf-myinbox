sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.everis.ias.controller.View1", {
		onInit: function () {
			var userModel = new JSONModel({});
			userModel.loadData("/iasscim/Users", null, true, 'GET', null, null, {
				'Content-Type': 'application/scim+json'
			}).then(() => {
				console.log("***IAS**");
				console.log(userModel.getData());
			}).catch(err => {
				console.log("***fail**");
				console.log(err);

			});
		}
	});
});