sap.ui.define([
	"com/everis/ias/test/unit/controller/View1.controller"
], function () {
	"use strict";
});