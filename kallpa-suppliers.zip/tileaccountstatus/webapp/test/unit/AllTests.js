sap.ui.define([
	"com/everis/suppliers/tileaccountstatus/test/unit/controller/App.controller"
], function () {
	"use strict";
});