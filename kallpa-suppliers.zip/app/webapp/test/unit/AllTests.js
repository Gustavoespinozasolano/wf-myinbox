sap.ui.define([
	"businessappsup/app/test/unit/controller/View1.controller"
], function () {
	"use strict";
});