sap.ui.define([
	"com/everis/suppliers/bpcreationrequest/test/unit/controller/Home.controller"
], function () {
	"use strict";
});