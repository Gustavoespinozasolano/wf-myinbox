sap.ui.define([
	"com/everis/suppliers/potracking/test/unit/controller/Home.controller"
], function () {
	"use strict";
});