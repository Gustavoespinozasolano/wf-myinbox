function initModel() {
	var sUrl = "/saperp/sap/opu/odata/eper/suppliers_srv/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}